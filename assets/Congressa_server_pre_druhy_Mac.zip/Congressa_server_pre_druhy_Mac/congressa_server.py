#!/usr/bin/env python3
"""
Congressa server — backend pre konferenčnú aplikáciu Congressa (iOS/iPadOS účastník, macOS administrátor).

Čo robí:
  • uchováva publikovaný program (JSON vo formáte aplikácie) a vydáva ho účastníkom (GET /api/program),
  • eviduje zariadenia účastníkov (APNs token, preferencie upozornení, obľúbené body programu),
  • posiela push notifikácie: automaticky pred každým bodom programu podľa preferencií zariadenia
    (body „Upozorniť všetkých“ dostanú všetci), naplánované oznamy, okamžité oznamy organizátora,
    „Program aktualizovaný“ po publikovaní,
  • eviduje prihlášky na body programu (kapacita, čakacia listina), exportuje prezenčné listiny,
  • uchováva zoznam účastníkov s prístupovými kódmi (overenie skupiny),
  • AI import programu z textu webu/PDF (POST /api/admin/import-ai, Claude API),
  • webový admin dashboard na /admin.

Rovnako ako Carpoolka server: len štandardná knižnica Pythonu (žiadny pip install), dáta v jednom
súbore SQLite (congressa.db). Push notifikácie cez APNs HTTP/2 používajú nástroje `curl` a `openssl`
(sú na každom Macu aj Linuxe) — Python stdlib nemá HTTP/2 ani ES256.

Spustenie:  python3 congressa_server.py              (port 8000)
            PORT=9000 python3 congressa_server.py
Premenné prostredia sú popísané v .env.example a README.md.
"""

import base64
import csv
import hashlib
import hmac
import io
import ipaddress
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

SERVER_VERSION = "1.1.0"
# Verzia JSON schémy programu (Conference) — aplikácie ju porovnávajú s tým, čo vedia čítať.
SCHEMA_VERSION = 1
# Najnižšie verzie aplikácií, ktoré s týmto serverom plne fungujú (od 1.1.0 server nevydáva accessCodes —
# staršie aplikácie overovali prístupový kód lokálne z programu, novšie cez POST /api/verify-code).
MIN_APP_VERSION = {"ios": "2.6", "android": "1.4", "macos": "2.6"}
HERE = os.path.dirname(os.path.abspath(__file__))


def _build_id():
    """Odtlacok tohto suboru — v /api/health ukazuje, ktora verzia servera naozaj bezi."""
    try:
        with open(os.path.abspath(__file__), "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()[:12]
    except Exception:
        return "?"


BUILD_ID = _build_id()
STARTED_AT = datetime.now(timezone.utc)
DB_PATH = os.environ.get("CONGRESSA_DB", os.path.join(HERE, "congressa.db"))
PORT = int(os.environ.get("PORT", "8000"))
ADMIN_TOKEN = os.environ.get("CONGRESSA_ADMIN_TOKEN", "")

# --- APNs (push) ---
APNS_KEY_FILE = os.environ.get("CONGRESSA_APNS_KEY_FILE", "")          # cesta k AuthKey_XXXXXXXXXX.p8
APNS_KEY_ID = os.environ.get("CONGRESSA_APNS_KEY_ID", "")              # 10-znakové Key ID z Apple Developer
APNS_TEAM_ID = os.environ.get("CONGRESSA_APNS_TEAM_ID", "")            # Team ID (napr. QS4A9TCFAU)
APNS_TOPIC = os.environ.get("CONGRESSA_APNS_TOPIC", "sk.sikuta.Congressa")  # bundle ID aplikácie
APNS_ENV = os.environ.get("CONGRESSA_APNS_ENV", "sandbox")             # sandbox (Xcode build) | production (TestFlight/App Store)
PUSH_INTERVAL = int(os.environ.get("CONGRESSA_PUSH_INTERVAL", "30"))   # sekundy medzi kontrolami plánovaných upozornení
BACKUP_DIR = os.environ.get("CONGRESSA_BACKUP_DIR", os.path.join(HERE, "backups"))
# Voliteľná offsite záloha e-mailom (prázdny e-mail = vypnuté).
BACKUP_EMAIL = os.environ.get("CONGRESSA_BACKUP_EMAIL", "").strip()
SMTP_HOST = os.environ.get("CONGRESSA_SMTP_HOST", "smtp.mail.me.com").strip()
SMTP_PORT = int(os.environ.get("CONGRESSA_SMTP_PORT", "587"))
SMTP_USER = os.environ.get("CONGRESSA_SMTP_USER", "").strip()
SMTP_PASSWORD = os.environ.get("CONGRESSA_SMTP_PASSWORD", "")
# --- AI import programu (voliteľné): Claude API kľúč ostáva len na serveri, aplikácia pošle text webu/PDF ---
AI_API_KEY = os.environ.get("CONGRESSA_AI_API_KEY", "")
AI_MODEL = os.environ.get("CONGRESSA_AI_MODEL", "claude-opus-5")
AI_API_URL = os.environ.get("CONGRESSA_AI_API_URL", "https://api.anthropic.com/v1/messages")
# Verejný AI import pre účastníkov (Congressa cloud): bez admin tokenu, s denným limitom na IP adresu.
PUBLIC_AI = os.environ.get("CONGRESSA_PUBLIC_AI", "") in ("1", "true", "yes")
PUBLIC_AI_DAILY_LIMIT = int(os.environ.get("CONGRESSA_PUBLIC_AI_DAILY_LIMIT", "10"))
# Ochrana osobných údajov: push_log a audit staršie ako toľko dní sa mažú (0 = nikdy).
RETENTION_DAYS = int(os.environ.get("CONGRESSA_RETENTION_DAYS", "180"))

# Polia programu, ktoré sú len pre organizátora — verejný GET /api/program ich nikdy nevydá.
# (accessCodes = odtlačky prístupových kódov + skupiny: z verejného JSON-u by sa dali prelomiť hrubou silou.)
PUBLIC_PROGRAM_STRIP = ("accessCodes", "attendees", "adminNotes")
# Najväčšie povolené telo požiadavky podľa cesty (bajty) — verejný server sa nesmie dať zhodiť obrím telom.
MAX_BODY = {"/api/admin/program": 25_000_000, "/api/admin/attendees": 5_000_000,
            "/api/import-ai": 1_000_000, "/api/admin/import-ai": 1_000_000}
DEFAULT_MAX_BODY = 64_000
# Admin heslo: po toľkých neúspešných pokusoch z jednej IP za ADMIN_FAIL_WINDOW sekúnd server odpovedá 429.
ADMIN_FAIL_LIMIT = 10
ADMIN_FAIL_WINDOW = 600

_local = threading.local()
_lock = threading.Lock()


# ----------------------------------------------------------------------------------------------
# Databáza
# ----------------------------------------------------------------------------------------------

def db():
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = sqlite3.connect(DB_PATH, timeout=10)
        conn.row_factory = sqlite3.Row
        _local.conn = conn
    return conn


def init_schema():
    conn = sqlite3.connect(DB_PATH)
    # WAL: čítania (účastníci, admin refresh) neblokujú zápisy plánovača a prihlášok → menej „database is locked“.
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS program (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            json TEXT NOT NULL,
            version INTEGER NOT NULL,
            name TEXT NOT NULL,
            published_at TEXT NOT NULL
        );
        -- Zoznam účastníkov organizátora (mená, e-maily, kódy) — nikdy sa nevydáva účastníkom.
        CREATE TABLE IF NOT EXISTS attendees (
            id TEXT PRIMARY KEY,
            json TEXT NOT NULL,
            code_hash TEXT,
            grp TEXT,
            updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS attendees_code ON attendees(code_hash);
        -- Zariadenia účastníkov: token, preferencie, obľúbené.
        CREATE TABLE IF NOT EXISTS devices (
            id TEXT PRIMARY KEY,
            json TEXT NOT NULL,
            platform TEXT,
            push_token TEXT,
            code_hash TEXT,
            grp TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_seen TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS registrations (
            id TEXT PRIMARY KEY,
            device_id TEXT NOT NULL,
            session_id TEXT NOT NULL,
            status TEXT NOT NULL,
            code_hash TEXT,
            name TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(device_id, session_id)
        );
        CREATE TABLE IF NOT EXISTS push_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            at TEXT NOT NULL,
            kind TEXT NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            sent INTEGER NOT NULL,
            failed INTEGER NOT NULL,
            detail TEXT
        );
        -- Už odoslané plánované upozornenia (aby po reštarte nešli znova).
        CREATE TABLE IF NOT EXISTS push_sent (
            key TEXT PRIMARY KEY,
            at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            at TEXT NOT NULL,
            action TEXT NOT NULL,
            detail TEXT
        );
        """
    )
    conn.commit()
    conn.close()


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def parse_iso(s):
    """ISO-8601 z aplikácie (Swift .iso8601 → '2026-09-03T08:30:00Z' alebo s offsetom)."""
    if not s:
        return None
    try:
        s = s.replace("Z", "+00:00")
        if "." in s:  # zlomky sekúnd
            s = re.sub(r"\.\d+", "", s)
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def code_hash(code):
    """Rovnaké ako CodeHasher v aplikácii: trim, bez medzier a pomlčiek, veľké písmená, SHA-256 hex."""
    norm = code.strip().replace(" ", "").replace("-", "").upper()
    if not norm:
        return ""
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()


def audit(action, detail=""):
    db().execute("INSERT INTO audit(at, action, detail) VALUES (?,?,?)", (now_iso(), action, detail))
    db().commit()


def log(*parts):
    """Riadok do konzoly/server.log s časovou pečiatkou."""
    print(now_iso(), *parts, flush=True)


def client_ip(h):
    """IP klienta. X-Forwarded-For platí len keď požiadavka prišla z loopbacku (Tailscale Funnel / reverzná proxy)."""
    ip = h.client_address[0]
    if ip in ("127.0.0.1", "::1", "::ffff:127.0.0.1"):
        fwd = (h.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
        if fwd:
            return fwd
    return ip


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ----------------------------------------------------------------------------------------------
# Program
# ----------------------------------------------------------------------------------------------

def load_program():
    row = db().execute("SELECT json, version, name, published_at FROM program WHERE id = 1").fetchone()
    if not row:
        return None
    return json.loads(row["json"])


def program_meta():
    row = db().execute("SELECT version, name, published_at FROM program WHERE id = 1").fetchone()
    return dict(row) if row else None


def save_program(conf):
    version = int(conf.get("version") or 1)
    # Účastnícke aplikácie (iPhone aj Android) sťahujú program podľa ETagu = verzia. Keby organizátor publikoval
    # tú istú alebo nižšiu verziu (obnovená záloha, druhý Mac, ručný curl), dostali by 304 a zmeny by nevideli —
    # preto verzia na serveri vždy rastie.
    previous = program_meta()
    if previous and version <= int(previous["version"] or 0):
        version = int(previous["version"]) + 1
        conf["version"] = version
    name = conf.get("name") or "Konferencia"
    conf.setdefault("publishedAt", now_iso())
    db().execute(
        "INSERT INTO program(id, json, version, name, published_at) VALUES (1,?,?,?,?) "
        "ON CONFLICT(id) DO UPDATE SET json=excluded.json, version=excluded.version, name=excluded.name, published_at=excluded.published_at",
        (json.dumps(conf, ensure_ascii=False), version, name, now_iso()),
    )
    db().commit()
    return version


def sessions_by_id(conf):
    return {s.get("id"): s for s in (conf or {}).get("sessions", [])}


_public_program_cache = {"version": None, "body": b""}


def public_program_body(row):
    """JSON programu pre účastníkov: bez organizátorských polí (PUBLIC_PROGRAM_STRIP). Uložený JSON ostáva úplný
    (resolve_group číta accessCodes z neho). Výsledok sa cachuje podľa verzie."""
    with _lock:
        if _public_program_cache["version"] == row["version"]:
            return _public_program_cache["body"]
    conf = json.loads(row["json"])
    for key in PUBLIC_PROGRAM_STRIP:
        conf.pop(key, None)
    body = json.dumps(conf, ensure_ascii=False).encode("utf-8")
    with _lock:
        _public_program_cache["version"] = row["version"]
        _public_program_cache["body"] = body
    return body


# ----------------------------------------------------------------------------------------------
# APNs push — JWT (ES256 cez openssl) + HTTP/2 cez curl
# ----------------------------------------------------------------------------------------------

def push_enabled():
    return bool(APNS_KEY_FILE and os.path.exists(APNS_KEY_FILE) and APNS_KEY_ID and APNS_TEAM_ID)


_jwt_cache = {"token": None, "at": 0}


def _b64url(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _der_to_raw_signature(der):
    """DER ECDSA podpis (SEQUENCE{INTEGER r, INTEGER s}) → 64 bajtov r||s (JWS formát)."""
    assert der[0] == 0x30
    i = 2
    assert der[i] == 0x02
    rlen = der[i + 1]
    r = der[i + 2:i + 2 + rlen]
    i = i + 2 + rlen
    assert der[i] == 0x02
    slen = der[i + 1]
    s = der[i + 2:i + 2 + slen]
    r = r.lstrip(b"\x00").rjust(32, b"\x00")
    s = s.lstrip(b"\x00").rjust(32, b"\x00")
    return r + s


def apns_jwt():
    """Provider token pre APNs, platí 60 min — obnovujeme po 50."""
    with _lock:
        if _jwt_cache["token"] and time.time() - _jwt_cache["at"] < 50 * 60:
            return _jwt_cache["token"]
        header = _b64url(json.dumps({"alg": "ES256", "kid": APNS_KEY_ID, "typ": "JWT"}).encode())
        claims = _b64url(json.dumps({"iss": APNS_TEAM_ID, "iat": int(time.time())}).encode())
        signing_input = (header + "." + claims).encode("ascii")
        proc = subprocess.run(["openssl", "dgst", "-sha256", "-sign", APNS_KEY_FILE], input=signing_input,
                              capture_output=True, check=True)
        sig = _b64url(_der_to_raw_signature(proc.stdout))
        token = header + "." + claims + "." + sig
        _jwt_cache["token"] = token
        _jwt_cache["at"] = time.time()
        return token


def apns_host():
    return "https://api.push.apple.com" if APNS_ENV == "production" else "https://api.sandbox.push.apple.com"


def apns_send_one(token, payload, collapse_id=None, expiration=None):
    """Pošle jednu notifikáciu. Vráti (ok, http_status, reason).
    `expiration`: unixový čas, dokedy má APNs notifikáciu doručovať — pripomienka po začiatku bodu už nemá zmysel."""
    url = "%s/3/device/%s" % (apns_host(), token)
    cmd = [
        "curl", "--http2", "-s", "-m", "15", "-o", "-", "-w", "\n%{http_code}",
        "-H", "authorization: bearer " + apns_jwt(),
        "-H", "apns-topic: " + APNS_TOPIC,
        "-H", "apns-push-type: alert",
        "-H", "apns-priority: 10",
        "-H", "content-type: application/json",
    ]
    if collapse_id:
        cmd += ["-H", "apns-collapse-id: " + collapse_id[:64]]
    if expiration:
        cmd += ["-H", "apns-expiration: %d" % int(expiration)]
    cmd += ["--data-binary", json.dumps(payload, ensure_ascii=False), url]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return False, 0, str(e)
    out = proc.stdout.rsplit("\n", 1)
    status = int(out[-1]) if out and out[-1].strip().isdigit() else 0
    body = out[0] if len(out) > 1 else ""
    reason = ""
    if body:
        try:
            reason = json.loads(body).get("reason", "")
        except ValueError:
            reason = body[:100]
    return status == 200, status, reason


PUSH_TTL = {"reminder": 0, "reminder-item": 0, "announcement": 24 * 3600, "program-update": 24 * 3600,
            "waitlist": 48 * 3600, "manual": 6 * 3600}


def send_push(devices, title, body, kind="manual", user_info=None, collapse_id=None, expires_at=None):
    """Pošle notifikáciu zoznamu zariadení (riadky/dicty s push_token, id). Zapíše do push_log. Vráti (sent, failed).
    `expires_at`: datetime, dokedy má zmysel doručiť (pripomienka = začiatok bodu); inak podľa PUSH_TTL druhu."""
    targets = [d for d in devices if d.get("push_token")]
    if not targets:
        log_push(kind, title, body, 0, 0, "žiadne zariadenie s push tokenom")
        return 0, 0
    if not push_enabled():
        log_push(kind, title, body, 0, len(targets), "push vypnutý — chýba APNs kľúč (.env)")
        return 0, len(targets)
    # Bez „badge“: odznak na ikone by ostal svietiť navždy (server nevie, čo si účastník prečítal).
    payload = {"aps": {"alert": {"title": title, "body": body}, "sound": "default"}}
    if user_info:
        payload.update(user_info)
    if expires_at is not None:
        expiration = int(expires_at.timestamp())
    else:
        ttl = PUSH_TTL.get(kind.split(":")[0], 6 * 3600)
        expiration = int(time.time()) + ttl if ttl else None
    sent = failed = 0
    dead = []
    reasons = {}

    def one(d):
        return d, apns_send_one(d["push_token"], payload, collapse_id, expiration)

    with ThreadPoolExecutor(max_workers=8) as pool:
        for d, (ok, status, reason) in pool.map(one, targets):
            if ok:
                sent += 1
            else:
                failed += 1
                reasons[reason or str(status)] = reasons.get(reason or str(status), 0) + 1
                if status == 410 or reason in ("BadDeviceToken", "Unregistered", "DeviceTokenNotForTopic"):
                    dead.append(d["id"])
    for did in dead:
        db().execute("UPDATE devices SET push_token = '' WHERE id = ?", (did,))
    if dead:
        db().commit()
    detail = ", ".join("%s×%d" % (k, v) for k, v in reasons.items())
    log_push(kind, title, body, sent, failed, detail)
    return sent, failed


def log_push(kind, title, body, sent, failed, detail=""):
    db().execute("INSERT INTO push_log(at, kind, title, body, sent, failed, detail) VALUES (?,?,?,?,?,?,?)",
                 (now_iso(), kind, title, body, sent, failed, detail))
    db().commit()


# ----------------------------------------------------------------------------------------------
# Plánovač: pripomienky pred bodmi programu a naplánované oznamy
# ----------------------------------------------------------------------------------------------

def all_devices():
    result = []
    for r in db().execute("SELECT * FROM devices").fetchall():
        data = json.loads(r["json"])
        result.append(dict(r, prefs=data.get("prefs", {}), favorites=set(data.get("favorites", []) or []),
                           favorite_items=set(data.get("favoriteItems", []) or []),
                           roles=set(data.get("roleSessions", []) or [])))
    return result


def device_registered_sessions(device_id):
    return {r["session_id"] for r in db().execute(
        "SELECT session_id FROM registrations WHERE device_id = ? AND status IN ('registered','waitlisted')", (device_id,))}


def should_remind(session, device, registered):
    p = device["prefs"]
    if not p.get("enabled", True):
        return False
    if session.get("isCancelled"):
        return False
    if session.get("notifyAll"):
        return True
    sid = session.get("id")
    if sid in device.get("roles", set()):
        return True  # vlastné vystúpenie / predsedanie / sprevádzanie — vždy
    if p.get("notifyFavorites", True) and sid in device["favorites"]:
        return True
    # Označené prednášky v režime „pred celým blokom“ pripomína blok (v režime „pred prednáškou“ majú vlastný push).
    if p.get("notifyFavorites", True) and p.get("itemReminder", "beforeItem") == "beforeBlock" \
            and any(i.get("id") in device.get("favorite_items", set()) for i in session.get("items", []) or []):
        return True
    if p.get("notifyRegistered", True) and sid in registered:
        return True
    kind = session.get("kind")
    if p.get("notifySocial", True) and kind == "social":
        return True
    if p.get("notifyMeetings", False) and kind == "meeting":
        return True
    return False


def session_body(conf, session, start_local):
    rooms = {r.get("id"): r for r in conf.get("rooms", [])}
    parts = ["%s · %s" % (start_local.strftime("%H:%M"), session.get("title", ""))]
    room = rooms.get(session.get("roomID"))
    if room and room.get("name"):
        parts.append(room["name"])
    return " — ".join(parts)


def item_start(session, item, conf):
    """Začiatok prednášky v bloku podľa textového času („09:50 - 10:35“, „11:40“) v zóne konferencie.
    Rovnaká logika ako `Session.itemStart` v aplikáciách: čas mimo okolia bloku (±30 min) sa ignoruje → None."""
    start = parse_iso(session.get("start"))
    end = parse_iso(session.get("end")) or start
    if not start:
        return None
    m = re.match(r"\s*(\d{1,2})[:.](\d{2})", str(item.get("time") or ""))
    if not m:
        return None
    hour, minute = int(m.group(1)), int(m.group(2))
    if hour > 23 or minute > 59:
        return None
    local = local_time(start, conf)
    candidate = local.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if not (start - timedelta(minutes=30) <= candidate <= end + timedelta(minutes=30)):
        return None
    return candidate


_scheduler_state = {"last_tick": None}


RETRY_WINDOW = timedelta(minutes=10)


def scheduler_tick():
    conf = load_program()
    if not conf:
        return
    now = datetime.now(timezone.utc)
    last = _scheduler_state["last_tick"] or (now - timedelta(seconds=90))
    _scheduler_state["last_tick"] = now
    devices = all_devices()
    if not devices:
        return
    # Pripomienky pred bodmi programu — podľa lead minút každého zariadenia.
    groups = {}  # (session_id, lead, own) -> [devices]
    for d in devices:
        if not d.get("push_token") or not d["prefs"].get("enabled", True):
            continue
        lead = int(d["prefs"].get("leadMinutes", 15) or 0)
        registered = device_registered_sessions(d["id"])
        for s in conf.get("sessions", []):
            start = parse_iso(s.get("start"))
            if not start:
                continue
            fire = start - timedelta(minutes=lead)
            # Okno siaha 10 min dozadu, aby sa zlyhaný push (výpadok, chýbajúci kľúč) skúsil znova.
            if not (min(last, now - RETRY_WINDOW) < fire <= now):
                continue
            if not should_remind(s, d, registered):
                continue
            key = "s:%s:%s" % (s.get("id"), d["id"])
            prev = db().execute("SELECT at FROM push_sent WHERE key = ?", (key,)).fetchone()
            if prev and prev["at"] != "failed":
                continue
            db().execute("INSERT OR REPLACE INTO push_sent(key, at) VALUES (?,?)", (key, now_iso()))
            groups.setdefault((s.get("id"), lead, s.get("id") in d.get("roles", set())), []).append(d)
    # Jednotlivé označené prednášky (režim „pred prednáškou“): podľa času prednášky, inak podľa začiatku bloku.
    item_groups = {}  # (session_id, item_id, lead) -> [devices]
    for d in devices:
        if not d.get("push_token") or not d["prefs"].get("enabled", True) or not d["prefs"].get("notifyFavorites", True):
            continue
        if d["prefs"].get("itemReminder", "beforeItem") != "beforeItem" or not d.get("favorite_items"):
            continue
        lead = int(d["prefs"].get("leadMinutes", 15) or 0)
        for s in conf.get("sessions", []):
            if s.get("isCancelled"):
                continue
            for item in s.get("items", []) or []:
                if item.get("id") not in d["favorite_items"]:
                    continue
                start_at = item_start(s, item, conf) or parse_iso(s.get("start"))
                if not start_at:
                    continue
                fire = start_at - timedelta(minutes=lead)
                if not (min(last, now - RETRY_WINDOW) < fire <= now):
                    continue
                key = "i:%s:%s" % (item.get("id"), d["id"])
                prev = db().execute("SELECT at FROM push_sent WHERE key = ?", (key,)).fetchone()
                if prev and prev["at"] != "failed":
                    continue
                db().execute("INSERT OR REPLACE INTO push_sent(key, at) VALUES (?,?)", (key, now_iso()))
                item_groups.setdefault((s.get("id"), item.get("id"), lead), []).append(d)
    db().commit()
    # Kľúč v push_sent je len „rezervácia“, aby sa notifikácia neposlala dvakrát. Ak odoslanie zlyhá
    # (chýbajúci APNs kľúč, výpadok siete), rezerváciu zrušíme a ďalší cyklus to skúsi znova.
    def release(prefix, item_id, devs):
        for d in devs:
            db().execute("UPDATE push_sent SET at = 'failed' WHERE key = ?", ("%s:%s:%s" % (prefix, item_id, d["id"]),))
        db().commit()
    sessions = sessions_by_id(conf)
    for (sid, lead, own), devs in groups.items():
        s = sessions[sid]
        start_local = local_time(parse_iso(s["start"]), conf)
        title = "Začína o %d min" % lead if s.get("kind") != "social" else "Spoločenský program"
        if lead == 0:
            title = "Začína teraz"
        if own:
            title = "Ste na rade o %d min" % lead if lead else "Ste na rade teraz"
        sent, _ = send_push(devs, title, session_body(conf, s, start_local), kind="reminder",
                            user_info={"sessionID": sid}, collapse_id="session-" + str(sid), expires_at=parse_iso(s["start"]))
        if sent == 0:
            release("s", sid, devs)
    rooms = {r.get("id"): r for r in conf.get("rooms", [])}
    for (sid, iid, lead), devs in item_groups.items():
        s = sessions.get(sid) or {}
        item = next((i for i in s.get("items", []) or [] if i.get("id") == iid), {})
        start_at = item_start(s, item, conf) or parse_iso(s.get("start"))
        start_local = local_time(start_at, conf)
        title = "Prednáška o %d min" % lead if lead else "Prednáška začína"
        parts = ["%s · %s" % (start_local.strftime("%H:%M"), item.get("title", "")), s.get("title", "")]
        room = rooms.get(s.get("roomID"))
        if room and room.get("name"):
            parts.append(room["name"])
        sent, _ = send_push(devs, title, " — ".join(p for p in parts if p), kind="reminder-item",
                            user_info={"sessionID": sid, "itemID": iid}, collapse_id="item-" + str(iid), expires_at=start_at)
        if sent == 0:
            release("i", iid, devs)
    # Naplánované oznamy.
    for a in conf.get("announcements", []):
        publish_at = parse_iso(a.get("publishAt"))
        if not publish_at or not (min(last, now - RETRY_WINDOW) < publish_at <= now):
            continue
        devs = []
        for d in devices:
            if not d.get("push_token") or not d["prefs"].get("enabled", True) or not d["prefs"].get("notifyAnnouncements", True):
                continue
            key = "a:%s:%s" % (a.get("id"), d["id"])
            prev = db().execute("SELECT at FROM push_sent WHERE key = ?", (key,)).fetchone()
            if prev and prev["at"] != "failed":
                continue
            db().execute("INSERT OR REPLACE INTO push_sent(key, at) VALUES (?,?)", (key, now_iso()))
            devs.append(d)
        db().commit()
        if devs:
            sev = a.get("severity", "info")
            title = a.get("title", "") if sev == "info" else "%s: %s" % ({"important": "Dôležité", "change": "Zmena programu"}.get(sev, sev), a.get("title", ""))
            sent, _ = send_push(devs, title, a.get("body", ""), kind="announcement", user_info={"announcementID": a.get("id")})
            if sent == 0:
                release("a", a.get("id"), devs)


def _last_sunday(year, month):
    d = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(days=1) if month < 12 else datetime(year, 12, 31, tzinfo=timezone.utc)
    return d - timedelta(days=(d.weekday() + 1) % 7)


def local_time(dt, conf):
    """Čas v zóne konferencie. Použije zoneinfo (Python 3.9+); na starších systémoch (macOS 12 má Python 3.8)
    záloha pre stredoeurópsky čas: CET/CEST podľa pravidla EÚ (posledná nedeľa marca/októbra, 01:00 UTC)."""
    tz_name = conf.get("timeZoneID") or "Europe/Bratislava"
    try:
        from zoneinfo import ZoneInfo
        return dt.astimezone(ZoneInfo(tz_name))
    except Exception:
        pass
    if tz_name.startswith("Europe/") and tz_name not in ("Europe/London", "Europe/Dublin", "Europe/Lisbon", "Europe/Moscow", "Europe/Kiev", "Europe/Kyiv", "Europe/Athens", "Europe/Helsinki", "Europe/Bucharest", "Europe/Sofia", "Europe/Riga", "Europe/Tallinn", "Europe/Vilnius", "Europe/Istanbul", "Europe/Minsk"):
        u = dt.astimezone(timezone.utc)
        start = _last_sunday(u.year, 3).replace(hour=1, minute=0, second=0, microsecond=0)
        end = _last_sunday(u.year, 10).replace(hour=1, minute=0, second=0, microsecond=0)
        offset = 2 if start <= u < end else 1
        return u.astimezone(timezone(timedelta(hours=offset)))
    return dt


def start_scheduler():
    def loop():
        while True:
            try:
                scheduler_tick()
            except Exception as e:  # noqa
                print("Plánovač: chyba", e, file=sys.stderr)
            time.sleep(PUSH_INTERVAL)
    threading.Thread(target=loop, daemon=True, name="congressa-scheduler").start()


# ----------------------------------------------------------------------------------------------
# AI import programu — text z webu / PDF → štruktúrovaný program (Claude API, štruktúrovaný výstup)
# Volá sa cez urllib (žiadne pip závislosti, rovnako ako zvyšok servera). Kľúč je len v .env servera.
# ----------------------------------------------------------------------------------------------

AI_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["name", "subtitle", "venueName", "venueAddress", "timeZoneID", "sessions", "notes"],
    "properties": {
        "name": {"type": "string", "description": "Short conference name (e.g. 'Forensic Days 2027')"},
        "subtitle": {"type": "string", "description": "Full official conference title, empty if unknown"},
        "venueName": {"type": "string"},
        "venueAddress": {"type": "string"},
        "timeZoneID": {"type": "string", "description": "IANA time zone of the venue, e.g. Europe/Bratislava"},
        "notes": {"type": "string", "description": "What could not be determined or looks ambiguous (for the organiser)"},
        "sessions": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["title", "kind", "date", "start", "end", "room", "track", "chairs", "speakers", "notes", "requiresRegistration", "items"],
                "properties": {
                    "title": {"type": "string"},
                    "kind": {"type": "string", "enum": ["lecture", "workshop", "symposium", "poster", "discussion", "meeting", "social", "break", "registration", "other"]},
                    "date": {"type": "string", "description": "YYYY-MM-DD"},
                    "start": {"type": "string", "description": "HH:MM 24h local time"},
                    "end": {"type": "string", "description": "HH:MM 24h local time; if unknown, estimate from the next item or typical duration"},
                    "room": {"type": "string", "description": "Hall / room / venue name, empty if unknown"},
                    "track": {"type": "string", "description": "Programme track or section name, empty if none"},
                    "chairs": {"type": "array", "items": {"type": "string"}, "description": "Chairs / moderators as 'I. Surname'"},
                    "speakers": {"type": "array", "items": {"type": "string"}, "description": "Speakers of the whole block (invited lecture, keynote) as 'I. Surname'"},
                    "notes": {"type": "string", "description": "Practical info: meeting point, dress code, ticket price, itinerary"},
                    "requiresRegistration": {"type": "boolean", "description": "True for dinners, trips, workshops with limited capacity"},
                    "items": {
                        "type": "array",
                        "description": "Individual presentations / posters inside the block",
                        "items": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["time", "code", "title", "authors", "affiliation"],
                            "properties": {
                                "time": {"type": "string", "description": "'11:40' or '09:50 - 10:35' or empty"},
                                "code": {"type": "string", "description": "Presentation code such as OP-1, PP-3, empty if none"},
                                "title": {"type": "string"},
                                "authors": {"type": "string", "description": "Authors exactly as printed, e.g. 'Sikuta, J., Kuruc, R.'"},
                                "affiliation": {"type": "string"},
                            },
                        },
                    },
                },
            },
        },
    },
}

AI_SYSTEM = (
    "You extract a scientific conference programme from raw website or PDF text into structured JSON for a conference "
    "companion app. Keep only real programme entries with a time: lectures, sessions/blocks with their presentations, "
    "posters, symposia, workshops, discussions, registration, opening/closing ceremonies, coffee breaks, lunches, dinners, "
    "parties, trips and other social programme. Skip navigation, sponsors, fees, submission deadlines, cookie notices. "
    "Group individual presentations (OP-1, PP-3, keynote titles with authors) as items inside their parent block; a block "
    "gets kind 'lecture' (or 'poster' for poster sessions, 'symposium' for symposia). Use the day headings to assign dates; "
    "if the year is missing, use the year given in the request. Times are local venue time, 24-hour. Chairs are listed as "
    "'Chairs: A. Luna' → ['A. Luna']. For dinners, trips, excursions set requiresRegistration true and put meeting point / "
    "itinerary / price into notes. Keep titles and names exactly as written (do not translate). If the text contains several "
    "halls or parallel tracks, put the hall name into 'room'."
)


def ai_import(text, source_url="", year=None, time_zone="Europe/Bratislava"):
    if not AI_API_KEY:
        raise ApiError(503, "AI import nie je zapnutý — doplňte CONGRESSA_AI_API_KEY do .env servera.")
    text = (text or "").strip()
    if len(text) < 40:
        raise ApiError(400, "Text programu je prázdny alebo príliš krátky.")
    if len(text) > 400000:
        text = text[:400000]
    user = "Source: %s\nAssumed year if missing: %s\nVenue time zone: %s\n\n=== TEXT START ===\n%s\n=== TEXT END ===" % (
        source_url or "(pasted text)", year or datetime.now().year, time_zone, text)
    body = {
        "model": AI_MODEL,
        "max_tokens": 32000,
        "system": AI_SYSTEM,
        "messages": [{"role": "user", "content": user}],
        "output_config": {"effort": "high", "format": {"type": "json_schema", "schema": AI_SCHEMA}},
    }
    req = urllib.request.Request(AI_API_URL, data=json.dumps(body).encode("utf-8"), method="POST", headers={
        "Content-Type": "application/json", "x-api-key": AI_API_KEY, "anthropic-version": "2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            resp = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")[:500]
        raise ApiError(502, "Claude API odpovedalo chybou %s: %s" % (e.code, detail))
    except urllib.error.URLError as e:
        raise ApiError(502, "Claude API je nedostupné: %s" % e)
    if resp.get("stop_reason") == "refusal":
        raise ApiError(502, "Model odmietol požiadavku (refusal).")
    if resp.get("stop_reason") == "max_tokens":
        raise ApiError(502, "Program je príliš dlhý na jeden prechod — rozdeľte text (napr. po dňoch).")
    out = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text")
    try:
        data = json.loads(out)
    except ValueError:
        raise ApiError(502, "Model nevrátil platný JSON.")
    usage = resp.get("usage", {})
    audit("ai-import", "%s: %d bodov, tokens in %s / out %s" % (source_url or "text", len(data.get("sessions", [])), usage.get("input_tokens"), usage.get("output_tokens")))
    data["usage"] = {"inputTokens": usage.get("input_tokens", 0), "outputTokens": usage.get("output_tokens", 0), "model": resp.get("model", AI_MODEL)}
    return data


def html_to_text(html):
    """Hrubý prevod HTML na text (bez skriptov a štýlov, s odriadkovaním blokov)."""
    t = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", html)
    t = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</h\d>|</tr>|</td>|</th>|</section>|</article>", "\n", t)
    t = re.sub(r"<[^>]+>", " ", t)
    t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&ndash;", "–").replace("&mdash;", "—").replace("&quot;", '"').replace("&#39;", "'")
    t = re.sub(r"&#(\d+);", lambda m: chr(int(m.group(1))), t)
    t = re.sub(r"[ \t]+", " ", t)
    return re.sub(r"\n\s*\n+", "\n", t).strip()


def _assert_public_url(url):
    """SSRF ochrana: len http(s) a len verejné adresy. Server by inak na požiadanie sťahoval z tailnetu (100.x),
    z LAN alebo z localhostu (admin bez tokenu!)."""
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ApiError(400, "Adresa musí začínať http:// alebo https://.")
    host = parsed.hostname
    if host.lower() in ("localhost",) or host.endswith(".local"):
        raise ApiError(400, "Adresa %s nie je verejná." % host)
    try:
        infos = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise ApiError(400, "Adresu %s sa nepodarilo preložiť." % host)
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified \
                or ip in ipaddress.ip_network("100.64.0.0/10"):
            raise ApiError(400, "Adresa %s nie je verejná (privátna sieť)." % host)


class _SafeRedirects(urllib.request.HTTPRedirectHandler):
    """Každé presmerovanie prejde tou istou kontrolou; najviac 5 skokov."""
    max_redirections = 5

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _assert_public_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_http_opener = urllib.request.build_opener(_SafeRedirects())


def http_get_text(url, max_bytes=3_000_000, timeout=20):
    """Stiahne textovú stránku (HTML/JS/JSON/text) — najviac max_bytes, s User-Agentom a SSRF kontrolou."""
    _assert_public_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": "Congressa/%s (+conference programme import)" % SERVER_VERSION,
                                               "Accept": "text/html,application/xhtml+xml,application/json,text/plain;q=0.9,*/*;q=0.5"})
    with _http_opener.open(req, timeout=timeout) as r:
        ctype = r.headers.get("Content-Type", "") or ""
        if not any(t in ctype for t in ("html", "javascript", "json", "text", "xml")):
            raise ValueError("unsupported content type " + ctype)
        raw = r.read(max_bytes + 1)
        if len(raw) > max_bytes:
            raise ValueError("too large")
    m = re.search(r"charset=([\w-]+)", ctype)
    enc = m.group(1) if m else None
    if not enc:
        m = re.search(rb"<meta[^>]+charset=[\"\']?([\w-]+)", raw[:4000], re.I)
        enc = m.group(1).decode("ascii", "replace") if m else "utf-8"
    try:
        return raw.decode(enc, "replace")
    except LookupError:
        return raw.decode("utf-8", "replace")


PROGRAM_LINK_WORDS = ("program", "programme", "schedule", "agenda", "harmonogram", "timetable", "sessions", "scientific", "social", "abstract")


def crawl_conference_text(url, max_pages=8):
    """Stiahne stránku a podstránky, ktoré vyzerajú ako program (podľa odkazov), vrátane JSON vloženého v JS bundle.
    Vráti (text, zoznam zdrojov). PDF sa na serveri nečítajú (to robí aplikácia cez PDFKit)."""
    _assert_public_url(url)
    parsed = urllib.parse.urlparse(url)
    base = "%s://%s" % (parsed.scheme, parsed.netloc)
    seen, texts, sources = set(), [], []
    queue = [url]
    while queue and len(seen) < max_pages:
        u = queue.pop(0)
        if u in seen:
            continue
        seen.add(u)
        try:
            html = http_get_text(u)
        except Exception:
            continue
        sources.append(u)
        texts.append("### PAGE %s\n%s" % (u, html_to_text(html)))
        # Program vložený v JS bundle (React) — dá sa poslať ako JSON text.
        for src in re.findall(r'src="([^"]+\.js)"', html)[:4]:
            su = src if src.startswith("http") else base + "/" + src.lstrip("/")
            try:
                js = http_get_text(su)
            except Exception:
                continue
            for m in re.finditer(r"JSON\.parse\('((?:[^'\\]|\\.)*)'\)", js):
                raw = m.group(1)
                if re.search(r"\d{1,2}:\d{2}", raw) and len(raw) > 500:
                    texts.append("### EMBEDDED JSON %s\n%s" % (su, raw.replace("\\'", "'")[:150000]))
                    sources.append(su)
        for href, label in re.findall(r'<a[^>]+href="([^"#]+)"[^>]*>(.*?)</a>', html, flags=re.I | re.S):
            full = href if href.startswith("http") else (base + "/" + href.lstrip("/") if href.startswith("/") else None)
            if not full or urllib.parse.urlparse(full).netloc != parsed.netloc or full in seen:
                continue
            probe = (href + " " + re.sub(r"<[^>]+>", "", label)).lower()
            if any(w in probe for w in PROGRAM_LINK_WORDS) and not full.lower().endswith((".pdf", ".jpg", ".png")):
                queue.append(full)
    return "\n\n".join(texts), sources


# ----------------------------------------------------------------------------------------------
# HTTP handler a smerovanie
# ----------------------------------------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    server_version = "Congressa/" + SERVER_VERSION
    timeout = 30  # socket timeout: pomalé/prázdne spojenie (slowloris) nedrží vlákno donekonečna

    def log_message(self, fmt, *args):
        if os.environ.get("CONGRESSA_LOG_REQUESTS"):
            super().log_message(fmt, *args)

    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, status, payload, content_type, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        if filename:
            self.send_header("Content-Disposition", 'attachment; filename="%s"' % filename)
        self.end_headers()
        self.wfile.write(payload)

    def _read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        limit = MAX_BODY.get(urlparse(self.path).path, DEFAULT_MAX_BODY)
        if length > limit:
            self.close_connection = True  # telo sa nečíta — spojenie po odpovedi zavrieť
            raise ApiError(413, "Požiadavka je príliš veľká (max. %d kB)." % (limit // 1000))
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            raise ApiError(400, "Neplatný JSON.")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Admin-Token")
        self.end_headers()

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def _dispatch(self, method):
        parsed = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        try:
            for m, pattern, fn in ROUTES:
                if m != method:
                    continue
                match = re.fullmatch(pattern, parsed.path)
                if match:
                    fn(self, q, *match.groups())
                    return
            raise ApiError(404, "Neznáma cesta: %s %s" % (method, parsed.path))
        except ApiError as e:
            self._send_json(e.status, {"error": e.message})
        except Exception as e:  # noqa
            import traceback
            traceback.print_exc()
            self._send_json(500, {"error": "Chyba servera: %s" % e})


_admin_failures = {}  # ip -> [čas neúspešných pokusov]


def require_admin(h, q):
    if not ADMIN_TOKEN:
        raise ApiError(503, "Admin rozhranie je vypnuté — nastavte CONGRESSA_ADMIN_TOKEN v .env.")
    token = h.headers.get("X-Admin-Token") or q.get("token") or ""
    ip = client_ip(h)
    now = time.time()
    with _lock:
        recent = [t for t in _admin_failures.get(ip, []) if now - t < ADMIN_FAIL_WINDOW]
        _admin_failures[ip] = recent
        if len(recent) >= ADMIN_FAIL_LIMIT:
            raise ApiError(429, "Príliš veľa neúspešných pokusov o prihlásenie — skúste o 10 minút.")
    if not hmac.compare_digest(token.encode("utf-8"), ADMIN_TOKEN.encode("utf-8")):
        with _lock:
            _admin_failures.setdefault(ip, []).append(now)
        audit("admin-auth-failed", ip)
        raise ApiError(401, "Neplatné admin heslo.")
    with _lock:
        _admin_failures.pop(ip, None)


# --- verejné ---

def health(h, q):
    meta = program_meta()
    h._send_json(200, {
        "status": "ok", "name": "Congressa", "serverVersion": SERVER_VERSION, "schemaVersion": SCHEMA_VERSION,
        "minAppVersion": MIN_APP_VERSION,
        "conference": meta["name"] if meta else None, "programVersion": meta["version"] if meta else 0,
        "devices": db().execute("SELECT COUNT(*) FROM devices").fetchone()[0],
        "pushEnabled": push_enabled(), "apnsEnvironment": APNS_ENV if push_enabled() else None,
        "aiImportEnabled": bool(AI_API_KEY), "publicAIImport": bool(AI_API_KEY and PUBLIC_AI), "time": now_iso(),
        "build": BUILD_ID, "startedAt": STARTED_AT.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "uptimeHours": round((datetime.now(timezone.utc) - STARTED_AT).total_seconds() / 3600.0, 1),
    })


def get_program(h, q):
    row = db().execute("SELECT json, version FROM program WHERE id = 1").fetchone()
    if not row:
        raise ApiError(404, "Program ešte nebol publikovaný.")
    etag = '"v%d"' % row["version"]
    if h.headers.get("If-None-Match") == etag:
        h.send_response(304)
        h.end_headers()
        return
    body = public_program_body(row)
    h.send_response(200)
    h.send_header("Content-Type", "application/json; charset=utf-8")
    h.send_header("Content-Length", str(len(body)))
    h.send_header("ETag", etag)
    h.send_header("Cache-Control", "no-cache")
    h.send_header("Access-Control-Allow-Origin", "*")
    h.end_headers()
    h.wfile.write(body)


def resolve_group(hash_value):
    """Skupina podľa odtlačku kódu: zo zoznamu účastníkov, alebo z prístupových kódov v publikovanom programe
    (organizátor nemusel zoznam účastníkov synchronizovať — kódy sú aj v programe)."""
    if not hash_value:
        return None
    row = db().execute("SELECT grp FROM attendees WHERE code_hash = ?", (hash_value,)).fetchone()
    if row:
        return row["grp"]
    conf = load_program() or {}
    for code in conf.get("accessCodes", []) or []:
        if code.get("codeHash") == hash_value:
            return code.get("group") or None
    return None


def verify_code(h, q):
    """{codeHash} → {ok, group}. Od 1.1.0 nie sú odtlačky kódov vo verejnom programe — aplikácia overuje kód tu."""
    data = h._read_json()
    hash_value = re.sub(r"[^0-9a-f]", "", str(data.get("codeHash") or "").lower())[:64]
    if len(hash_value) != 64:
        raise ApiError(400, "Chýba codeHash.")
    grp = resolve_group(hash_value)
    h._send_json(200, {"ok": bool(grp), "group": grp})


def _secret_hash(secret):
    secret = str(secret or "").strip()
    return hashlib.sha256(secret.encode("utf-8")).hexdigest() if secret else ""


def register_device(h, q):
    data = h._read_json()
    device_id = str(data.get("deviceID") or "").strip()
    if not device_id or len(device_id) > 80:
        raise ApiError(400, "Chýba deviceID.")
    token = re.sub(r"[^0-9a-fA-F]", "", str(data.get("pushToken") or "")).lower()
    platform = str(data.get("platform") or "ios")[:20]
    hash_value = str(data.get("codeHash") or "")[:64]
    grp = resolve_group(hash_value) or str(data.get("group") or "")[:60]
    now = now_iso()
    existing = db().execute("SELECT created_at, json FROM devices WHERE id = ?", (device_id,)).fetchone()
    stored = {k: data.get(k) for k in ("name", "appVersion", "prefs", "favorites", "favoriteItems", "roleSessions", "speakerID", "timeZoneID")}
    # Tajomstvo zariadenia (appka si ho vygeneruje pri prvej registrácii): oprávňuje DELETE /api/devices/<id>.
    # Ukladá sa len odtlačok; raz nastavené sa bez neho neprepíše (zariadenie, ktoré ho nepozná, nie je majiteľ).
    previous_secret = json.loads(existing["json"]).get("secretHash", "") if existing else ""
    new_secret = _secret_hash(data.get("deviceSecret"))
    if previous_secret and new_secret and not hmac.compare_digest(previous_secret, new_secret):
        raise ApiError(403, "Toto zariadenie je už zaregistrované s iným tajomstvom.")
    stored["secretHash"] = previous_secret or new_secret
    db().execute(
        "INSERT INTO devices(id, json, platform, push_token, code_hash, grp, created_at, updated_at, last_seen) VALUES (?,?,?,?,?,?,?,?,?) "
        # Prázdny token (sync ešte pred príchodom APNs tokenu) nesmie zmazať ten uložený.
        "ON CONFLICT(id) DO UPDATE SET json=excluded.json, platform=excluded.platform, "
        "push_token=CASE WHEN excluded.push_token != '' THEN excluded.push_token ELSE devices.push_token END, "
        "code_hash=excluded.code_hash, grp=excluded.grp, updated_at=excluded.updated_at, last_seen=excluded.last_seen",
        (device_id, json.dumps(stored, ensure_ascii=False), platform, token, hash_value, grp,
         existing["created_at"] if existing else now, now, now),
    )
    db().commit()
    regs = [{"sessionID": r["session_id"], "status": r["status"], "updatedAt": r["updated_at"]}
            for r in db().execute("SELECT session_id, status, updated_at FROM registrations WHERE device_id = ?", (device_id,))]
    meta = program_meta()
    h._send_json(200, {"ok": True, "group": grp or None, "registrations": regs, "programVersion": meta["version"] if meta else 0})


def delete_device(h, q, device_id):
    """Právo na výmaz: zmaže zariadenie aj jeho prihlášky. Vyžaduje X-Device-Secret (appka od 2.6 / 1.4),
    alebo — pri zariadení bez tajomstva — codeHash zhodný s uloženým (telo alebo ?codeHash=)."""
    row = db().execute("SELECT json, code_hash FROM devices WHERE id = ?", (device_id,)).fetchone()
    if not row:
        h._send_json(200, {"ok": True, "deleted": False})
        return
    stored_secret = json.loads(row["json"]).get("secretHash", "") or ""
    given_secret = _secret_hash(h.headers.get("X-Device-Secret"))
    body = h._read_json() if int(h.headers.get("Content-Length") or 0) > 0 else {}
    given_hash = str((body or {}).get("codeHash") or q.get("codeHash") or "")[:64]
    if stored_secret:
        allowed = bool(given_secret) and hmac.compare_digest(stored_secret, given_secret)
    else:
        allowed = bool(row["code_hash"]) and bool(given_hash) and hmac.compare_digest(row["code_hash"], given_hash)
    if not allowed:
        raise ApiError(403, "Zariadenie môže odstrániť len aplikácia, ktorá ho zaregistrovala.")
    db().execute("DELETE FROM registrations WHERE device_id = ?", (device_id,))
    db().execute("DELETE FROM devices WHERE id = ?", (device_id,))
    db().commit()
    audit("device-deleted", device_id)
    h._send_json(200, {"ok": True, "deleted": True})


# Prihlášky menia kapacitu — čítanie stavu a zápis musia byť nedeliteľné, inak sa pri súbežných
# požiadavkách prekročí kapacita alebo sa ten istý čakateľ posunie dvakrát.
_registration_lock = threading.Lock()


def session_capacity_state(session_id):
    conf = load_program() or {}
    s = sessions_by_id(conf).get(session_id)
    capacity = s.get("capacity") if s else None
    registered = db().execute("SELECT COUNT(*) FROM registrations WHERE session_id = ? AND status = 'registered'", (session_id,)).fetchone()[0]
    return s, capacity, registered


def submit_registration(h, q):
    data = h._read_json()
    device_id = str(data.get("deviceID") or "").strip()
    session_id = str(data.get("sessionID") or "").strip()
    status = str(data.get("status") or "registered")
    if not device_id or not session_id:
        raise ApiError(400, "Chýba deviceID alebo sessionID.")
    if status not in ("registered", "cancelled", "waitlisted"):
        raise ApiError(400, "Neznámy stav.")
    hash_value = str(data.get("codeHash") or "")[:64]
    name = str(data.get("attendeeName") or "")[:120]
    now = now_iso()
    with _registration_lock:
        session, capacity, registered = session_capacity_state(session_id)
        # Vyhradené položky (výbor, workshop pre pozvaných) overuje aj server, nielen aplikácia —
        # inak by ich obsadil ktokoľvek, kto pozná adresu servera.
        allowed = [g.strip().lower() for g in ((session or {}).get("allowedGroups") or []) if g]
        if status != "cancelled" and allowed:
            grp = (resolve_group(hash_value) or "").strip().lower()
            if grp not in allowed:
                raise ApiError(403, "Táto položka je vyhradená pre inú skupinu. Zadajte prístupový kód od organizátora.")
        message = None
        existing = db().execute("SELECT status, created_at FROM registrations WHERE device_id = ? AND session_id = ?", (device_id, session_id)).fetchone()
        if status == "cancelled":
            final = "cancelled"
        else:
            if existing and existing["status"] == "registered":
                final = "registered"
            elif capacity is not None and registered >= capacity:
                final = "waitlisted"
                message = "Kapacita je naplnená — ste na čakacej listine."
            else:
                final = "registered"
        # Poradie na čakacej listine sa počíta od tejto prihlášky, nie od dávno zrušenej.
        created = existing["created_at"] if existing and existing["status"] != "cancelled" else now
        db().execute(
            "INSERT INTO registrations(id, device_id, session_id, status, code_hash, name, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?) "
            "ON CONFLICT(device_id, session_id) DO UPDATE SET status=excluded.status, code_hash=excluded.code_hash, name=excluded.name, "
            "created_at=excluded.created_at, updated_at=excluded.updated_at",
            (str(uuid.uuid4()), device_id, session_id, final, hash_value, name, created, now),
        )
        db().commit()
        # Uvoľnené miesto → posuň prvého z čakacej listiny.
        promote_pending = status == "cancelled" and existing and existing["status"] == "registered" and capacity is not None
    if promote_pending:
        promote_waitlisted(session_id, session)
    h._send_json(200, {"ok": True, "registration": {"sessionID": session_id, "status": final, "updatedAt": now}, "message": message})


def promote_waitlisted(session_id, session, check_capacity=False):
    """Posunie prvého čakateľa na uvoľnené miesto. Vráti True, ak sa niekto posunul.
    `check_capacity`: overiť voľné miesto pod zámkom (dopĺňanie po publikovaní)."""
    with _registration_lock:
        if check_capacity:
            _, cap, registered = session_capacity_state(session_id)
            if cap is None or registered >= cap:
                return False
        row = db().execute("SELECT id, device_id FROM registrations WHERE session_id = ? AND status = 'waitlisted' ORDER BY created_at, id LIMIT 1", (session_id,)).fetchone()
        if not row:
            return False
        # Podmienka na stav zabráni tomu, aby dve súbežné odhlásenia posunuli toho istého človeka.
        cur = db().execute("UPDATE registrations SET status = 'registered', updated_at = ? WHERE id = ? AND status = 'waitlisted'", (now_iso(), row["id"]))
        db().commit()
        if cur.rowcount != 1:
            return False
    dev = db().execute("SELECT id, push_token FROM devices WHERE id = ?", (row["device_id"],)).fetchone()
    if dev:
        title = session.get("title", "") if session else "Prihláška"
        send_push([dict(dev)], "Máte miesto: " + title, "Uvoľnilo sa miesto — vaša prihláška je potvrdená.", kind="waitlist",
                  user_info={"sessionID": session_id})
    return True


def list_registrations(h, q):
    device_id = q.get("deviceID", "")
    if not device_id:
        raise ApiError(400, "Chýba deviceID.")
    regs = [{"sessionID": r["session_id"], "status": r["status"], "updatedAt": r["updated_at"]}
            for r in db().execute("SELECT session_id, status, updated_at FROM registrations WHERE device_id = ?", (device_id,))]
    h._send_json(200, regs)


# --- admin ---

def admin_put_program(h, q):
    require_admin(h, q)
    conf = h._read_json()
    if not isinstance(conf, dict) or "sessions" not in conf:
        raise ApiError(400, "Očakávam JSON programu (Conference).")
    version = save_program(conf)
    audit("publish", "v%d %s" % (version, conf.get("name", "")))
    promoted = fill_free_seats(conf)
    if promoted:
        audit("waitlist", "posunutých z čakacej listiny: %d" % promoted)
    notified = 0
    if q.get("notify") in ("1", "true", "yes"):
        devs = [dict(d) for d in db().execute("SELECT id, push_token FROM devices WHERE push_token != ''")]
        notified, _ = send_push(devs, "Program bol aktualizovaný", "%s — verzia programu %d. Otvorte aplikáciu a pozrite si zmeny." % (conf.get("name", "Konferencia"), version),
                                kind="program-update", collapse_id="program-update")
    h._send_json(200, {"ok": True, "version": version, "notified": notified})


def fill_free_seats(conf):
    """Po publikovaní programu (napr. po zvýšení kapacity) doplní čakateľov do voľných miest."""
    promoted = 0
    for s in conf.get("sessions", []):
        capacity = s.get("capacity")
        if capacity is None:
            continue
        while promote_waitlisted(s.get("id"), s, check_capacity=True):
            promoted += 1
    return promoted


def admin_get_attendees(h, q):
    require_admin(h, q)
    h._send_json(200, [json.loads(r["json"]) for r in db().execute("SELECT json FROM attendees ORDER BY updated_at")])


def admin_put_attendees(h, q):
    require_admin(h, q)
    data = h._read_json()
    if not isinstance(data, list):
        raise ApiError(400, "Očakávam pole účastníkov.")
    now = now_iso()
    db().execute("DELETE FROM attendees")
    for a in data:
        aid = str(a.get("id") or uuid.uuid4())
        db().execute("INSERT INTO attendees(id, json, code_hash, grp, updated_at) VALUES (?,?,?,?,?)",
                     (aid, json.dumps(a, ensure_ascii=False), code_hash(str(a.get("code") or "")), str(a.get("group") or ""), now))
    # Doplň skupinu zariadeniam, ktoré už zadali kód.
    for d in db().execute("SELECT id, code_hash FROM devices WHERE code_hash != ''").fetchall():
        grp = resolve_group(d["code_hash"])
        if grp:
            db().execute("UPDATE devices SET grp = ? WHERE id = ?", (grp, d["id"]))
    db().commit()
    audit("attendees", "%d" % len(data))
    h._send_json(200, {"ok": True, "count": len(data)})


def attendee_by_hash(hash_value):
    if not hash_value:
        return None
    row = db().execute("SELECT json FROM attendees WHERE code_hash = ?", (hash_value,)).fetchone()
    return json.loads(row["json"]) if row else None


def build_registrations_report():
    conf = load_program() or {}
    sessions = sessions_by_id(conf)
    result = {}
    for r in db().execute("SELECT r.*, d.grp AS device_grp FROM registrations r LEFT JOIN devices d ON d.id = r.device_id ORDER BY r.created_at"):
        s = sessions.get(r["session_id"], {})
        entry = result.setdefault(r["session_id"], {
            "sessionID": r["session_id"], "sessionTitle": s.get("title", "(bod už nie je v programe)"), "start": s.get("start"),
            "capacity": s.get("capacity"), "registered": 0, "waitlisted": 0, "entries": []})
        att = attendee_by_hash(r["code_hash"]) or {}
        # Meno zo zoznamu organizátora má prednosť — meno z aplikácie si účastník môže napísať ľubovoľné.
        list_name = " ".join(x for x in (att.get("firstName", ""), att.get("lastName", "")) if x)
        name = list_name or r["name"] or ""
        entry["entries"].append({"deviceID": r["device_id"], "name": name, "email": att.get("email", ""), "group": att.get("group") or r["device_grp"] or "",
                                 "verifiedByCode": bool(att), "status": r["status"], "updatedAt": r["updated_at"]})
        if r["status"] == "registered":
            entry["registered"] += 1
        elif r["status"] == "waitlisted":
            entry["waitlisted"] += 1
    return sorted(result.values(), key=lambda e: e.get("start") or "")


def admin_registrations(h, q):
    require_admin(h, q)
    h._send_json(200, build_registrations_report())


def admin_registrations_csv(h, q):
    require_admin(h, q)
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["bod programu", "zaciatok", "meno", "email", "skupina", "overeny kodom", "stav", "aktualizovane"])
    for e in build_registrations_report():
        for x in e["entries"]:
            w.writerow([e["sessionTitle"], e.get("start") or "", x["name"], x["email"], x["group"], "ano" if x["verifiedByCode"] else "nie", x["status"], x["updatedAt"]])
    h._send_bytes(200, ("﻿" + buf.getvalue()).encode("utf-8"), "text/csv; charset=utf-8", "prihlaseni.csv")


def admin_devices(h, q):
    require_admin(h, q)
    rows = db().execute("SELECT platform, push_token, grp, last_seen FROM devices").fetchall()
    by_group = {}
    for r in rows:
        by_group[r["grp"] or ""] = by_group.get(r["grp"] or "", 0) + 1
    h._send_json(200, {
        "count": len(rows), "withPush": sum(1 for r in rows if r["push_token"]),
        "ios": sum(1 for r in rows if r["platform"] == "ios"), "android": sum(1 for r in rows if r["platform"] == "android"),
        "byGroup": by_group,
    })


def admin_push(h, q):
    require_admin(h, q)
    data = h._read_json()
    title = str(data.get("title") or "").strip()
    body = str(data.get("body") or "").strip()
    if not title:
        raise ApiError(400, "Chýba nadpis.")
    grp = data.get("group")
    if grp:
        devs = [dict(d) for d in db().execute("SELECT id, push_token FROM devices WHERE push_token != '' AND lower(grp) = lower(?)", (grp,))]
    else:
        devs = [dict(d) for d in db().execute("SELECT id, push_token FROM devices WHERE push_token != ''")]
    info = {"sessionID": data["sessionID"]} if data.get("sessionID") else None
    sent, failed = send_push(devs, title, body, kind="manual" + (":" + grp if grp else ""), user_info=info)
    # Okamžitý oznam býva zároveň publikovaný v programe s časom „teraz“; poznačíme ho ako odoslaný,
    # aby ho o pár sekúnd neposlal ešte raz plánovač.
    announcement_id = data.get("announcementID")
    if announcement_id and sent:
        for d in devs:
            db().execute("INSERT OR IGNORE INTO push_sent(key, at) VALUES (?,?)", ("a:%s:%s" % (announcement_id, d["id"]), now_iso()))
        db().commit()
    audit("push", title)
    msg = None if push_enabled() else "Push je vypnutý — doplňte APNs kľúč do .env (CONGRESSA_APNS_*)."
    h._send_json(200, {"ok": True, "sent": sent, "failed": failed, "message": msg})


def admin_push_log(h, q):
    require_admin(h, q)
    limit = min(500, int(q.get("limit", "50") or 50))
    rows = db().execute("SELECT * FROM push_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    h._send_json(200, [dict(r) for r in rows])


_public_ai_usage = {}


def public_import_ai(h, q):
    """Účastnícky AI import (Congressa cloud): {text, url, year, timeZoneID}. Limit CONGRESSA_PUBLIC_AI_DAILY_LIMIT na IP a deň."""
    if not (PUBLIC_AI and AI_API_KEY):
        raise ApiError(404, "Verejný AI import nie je na tomto serveri zapnutý.")
    ip = h.headers.get("X-Forwarded-For", h.client_address[0]).split(",")[0].strip()
    day = datetime.now().strftime("%Y-%m-%d")
    with _lock:
        used = _public_ai_usage.get((ip, day), 0)
        if used >= PUBLIC_AI_DAILY_LIMIT:
            raise ApiError(429, "Denný limit AI rozpoznaní pre túto adresu je vyčerpaný — skúste zajtra alebo použite vlastný API kľúč.")
        _public_ai_usage[(ip, day)] = used + 1
    data = h._read_json()
    text = str(data.get("text") or "")
    url = str(data.get("url") or "").strip()
    if not text.strip() and url.startswith("http"):
        text, _ = crawl_conference_text(url)
    result = ai_import(text, source_url=url, year=data.get("year"), time_zone=str(data.get("timeZoneID") or "Europe/Bratislava"))
    h._send_json(200, result)


def admin_import_ai(h, q):
    """{url?, text?, year?, timeZoneID?} → štruktúrovaný program. Ak je text, použije sa (aplikácia ho už vyzbierala z webu/PDF);
    inak server stiahne stránku a podstránky s programom sám."""
    require_admin(h, q)
    data = h._read_json()
    text = str(data.get("text") or "")
    url = str(data.get("url") or "").strip()
    sources = []
    if not text.strip() and url:
        if not url.startswith("http"):
            raise ApiError(400, "Neplatná adresa.")
        text, sources = crawl_conference_text(url)
    result = ai_import(text, source_url=url, year=data.get("year"), time_zone=str(data.get("timeZoneID") or "Europe/Bratislava"))
    result["sources"] = sources
    h._send_json(200, result)


def admin_overview(h, q):
    require_admin(h, q)
    meta = program_meta()
    conf = load_program() or {}
    kinds = {}
    for s in conf.get("sessions", []):
        kinds[s.get("kind", "other")] = kinds.get(s.get("kind", "other"), 0) + 1
    rows = db().execute("SELECT platform, push_token, grp, last_seen, json FROM devices ORDER BY last_seen DESC").fetchall()
    h._send_json(200, {
        "program": meta, "conference": {k: conf.get(k) for k in ("name", "subtitle", "startDate", "endDate", "venueName", "venueAddress", "feedURL")},
        "sessionsByKind": kinds, "sessions": len(conf.get("sessions", [])), "announcements": len(conf.get("announcements", [])),
        "attendees": db().execute("SELECT COUNT(*) FROM attendees").fetchone()[0],
        "devices": [{"platform": r["platform"], "push": bool(r["push_token"]), "group": r["grp"], "lastSeen": r["last_seen"],
                     "name": json.loads(r["json"]).get("name", ""), "appVersion": json.loads(r["json"]).get("appVersion", "")} for r in rows],
        "registrations": build_registrations_report(),
        "pushLog": [dict(r) for r in db().execute("SELECT * FROM push_log ORDER BY id DESC LIMIT 30")],
        "pushEnabled": push_enabled(), "apnsEnvironment": APNS_ENV, "apnsTopic": APNS_TOPIC, "aiImportEnabled": bool(AI_API_KEY), "aiModel": AI_MODEL,
        "audit": [dict(r) for r in db().execute("SELECT * FROM audit ORDER BY id DESC LIMIT 30")],
    })


def consistent_db_copy(dst):
    """Konzistentná kópia DB cez SQLite backup API (živý súbor môže mať rozpísanú transakciu / WAL)."""
    src = sqlite3.connect(DB_PATH)
    out = sqlite3.connect(dst)
    with out:
        src.backup(out)
    out.close()
    src.close()


def admin_export_db(h, q):
    require_admin(h, q)
    fd, tmp = tempfile.mkstemp(prefix="congressa-export-", suffix=".db")
    os.close(fd)
    try:
        consistent_db_copy(tmp)
        with open(tmp, "rb") as f:
            data = f.read()
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    h._send_bytes(200, data, "application/octet-stream", "congressa.db")


def admin_purge(h, q):
    """Ukončenie konferencie: záloha → vymazať osobné údaje (účastníci, zariadenia, prihlášky, odoslané push),
    program ostáva (bez prístupových kódov), audit ostáva."""
    require_admin(h, q)
    os.makedirs(BACKUP_DIR, exist_ok=True)
    backup = os.path.join(BACKUP_DIR, "pred-purge-%s.db" % datetime.now().strftime("%Y-%m-%d-%H%M%S"))
    consistent_db_copy(backup)
    conn = db()
    counts = {t: conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0] for t in ("attendees", "devices", "registrations")}
    with _registration_lock:
        for t in ("attendees", "devices", "registrations", "push_sent"):
            conn.execute("DELETE FROM %s" % t)
        conn.execute("UPDATE push_log SET detail = ''")
        row = conn.execute("SELECT json, version FROM program WHERE id = 1").fetchone()
        if row:
            conf = json.loads(row["json"])
            for key in PUBLIC_PROGRAM_STRIP:
                conf.pop(key, None)
            conn.execute("UPDATE program SET json = ? WHERE id = 1", (json.dumps(conf, ensure_ascii=False),))
        conn.commit()
    with _lock:
        _public_program_cache["version"] = None
    audit("purge", "účastníci %(attendees)d, zariadenia %(devices)d, prihlášky %(registrations)d" % counts)
    h._send_json(200, {"ok": True, "deleted": counts, "backup": os.path.basename(backup)})


ADMIN_HTML = r"""<!doctype html>
<html lang="sk"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Congressa Admin</title>
<style>
 body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;margin:0;background:#f4f5f9;color:#111}
 header{background:#0B0E9D;color:#fff;padding:14px 22px;display:flex;justify-content:space-between;align-items:center}
 header h1{font-size:18px;margin:0}
 main{padding:18px 22px;max-width:1200px;margin:0 auto}
 .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:18px}
 .card{background:#fff;border-radius:10px;padding:14px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
 .card b{display:block;font-size:26px}.card span{color:#666;font-size:13px}
 section{background:#fff;border-radius:10px;padding:16px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
 h2{font-size:16px;margin:0 0 10px}
 table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid #eee;vertical-align:top}
 th{color:#666;font-weight:600}
 input,textarea,select{font:inherit;padding:8px;border:1px solid #ccd;border-radius:6px;width:100%;box-sizing:border-box}
 button{font:inherit;padding:8px 14px;border:0;border-radius:6px;background:#0B0E9D;color:#fff;cursor:pointer}
 button.sec{background:#e5e7f5;color:#0B0E9D}
 .row{display:flex;gap:10px;flex-wrap:wrap;align-items:end}.row>*{flex:1;min-width:160px}
 .ok{color:#178a3a}.bad{color:#b91c1c}.muted{color:#777}
 #login{max-width:420px;margin:60px auto}
 .tag{display:inline-block;padding:2px 8px;border-radius:999px;background:#eef;font-size:12px}
</style></head><body>
<header><h1>Congressa Admin — server konferencie</h1><div><span id="who" class="muted"></span> <button class="sec" onclick="logout()">Odhlásiť</button></div></header>
<main>
<div id="login" class="card"><h2>Prihlásenie</h2><p class="muted">Admin heslo je CONGRESSA_ADMIN_TOKEN v súbore .env servera (vypíše sa aj pri spustení).</p>
<input id="tok" type="password" placeholder="Admin heslo"><br><br><button onclick="login()">Prihlásiť</button><p id="loginerr" class="bad"></p></div>
<div id="app" style="display:none">
 <div class="cards" id="cards"></div>
 <section><h2>Poslať push oznam všetkým zariadeniam</h2>
  <div class="row"><div><label>Nadpis</label><input id="ptitle" placeholder="Obed sa podáva"></div><div><label>Skupina (prázdne = všetci)</label><input id="pgroup" placeholder="ucastnik"></div></div>
  <label>Text</label><textarea id="pbody" rows="2" placeholder="Obed sa podáva vo foyer do 14:00."></textarea><br><br>
  <button onclick="sendPush()">Odoslať push</button> <span id="pushres"></span>
  <p class="muted">Poznámka: oznam odoslaný odtiaľto ide len ako push; oznam z macOS aplikácie sa navyše uloží do programu (uvidia ho aj tí, čo push nemajú).</p>
 </section>
 <section><h2>Program</h2><div id="program"></div>
 </section>
 <section><h2>Prihlásení na body programu <a href="#" onclick="dl('registrations.csv');return false" style="font-weight:normal;font-size:13px">↓ CSV</a></h2><div id="regs"></div></section>
 <section><h2>Zariadenia</h2><div id="devices"></div></section>
 <section><h2>Odoslané push notifikácie</h2><div id="pushlog"></div></section>
 <section><h2>Audit</h2><div id="audit"></div><p><a href="#" onclick="dl('export-db');return false">Stiahnuť zálohu databázy (congressa.db)</a></p></section>
 <section><h2>Ukončenie konferencie</h2><p class="muted">Po konferencii vymažte osobné údaje: zoznam účastníkov, zariadenia, prihlášky a odoslané push. Program ostane (bez prístupových kódov), server si predtým urobí zálohu do backups/pred-purge-….db.</p>
  <button class="sec" onclick="purge()">Vymazať údaje účastníkov…</button> <span id="purgeres"></span></section>
</div></main>
<script>
let T=localStorage.getItem('congressa_admin')||'';
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function fmt(s){if(!s)return '';const d=new Date(s);return isNaN(d)?s:d.toLocaleString('sk-SK')}
async function api(path,opts){opts=opts||{};opts.headers=Object.assign({'X-Admin-Token':T,'Content-Type':'application/json'},opts.headers||{});const r=await fetch(path,opts);const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j}
async function login(){T=document.getElementById('tok').value.trim();try{await api('/api/admin/devices');localStorage.setItem('congressa_admin',T);show()}catch(e){document.getElementById('loginerr').textContent=e.message}}
function logout(){localStorage.removeItem('congressa_admin');T='';location.reload()}
function dl(what){window.open('/api/admin/'+what+'?token='+encodeURIComponent(T),'_blank')}
async function show(){document.getElementById('login').style.display='none';document.getElementById('app').style.display='';await refresh();setInterval(refresh,15000)}
async function refresh(){let o;try{o=await api('/api/admin/overview')}catch(e){document.getElementById('cards').innerHTML='<div class="card bad">'+esc(e.message)+'</div>';return}
 const dev=o.devices||[];const withPush=dev.filter(d=>d.push).length;
 document.getElementById('who').textContent=(o.conference&&o.conference.name)||'';
 document.getElementById('cards').innerHTML=[['Verzia programu',o.program?o.program.version:'—','publikované '+(o.program?fmt(o.program.published_at):'nikdy')],['Bodov programu',o.sessions,Object.entries(o.sessionsByKind||{}).map(([k,v])=>k+' '+v).join(', ')],['Zariadenia',dev.length,'s push tokenom: '+withPush],['Účastníci v zozname',o.attendees,'s kódmi zo Mac aplikácie'],['Push',o.pushEnabled?'zapnutý':'vypnutý',o.pushEnabled?(o.apnsEnvironment+' · '+o.apnsTopic):'doplňte CONGRESSA_APNS_* do .env']].map(c=>'<div class="card"><span>'+esc(c[0])+'</span><b>'+esc(c[1])+'</b><span>'+esc(c[2])+'</span></div>').join('');
 const c=o.conference||{};document.getElementById('program').innerHTML=o.program?'<p><b>'+esc(c.name)+'</b> — '+esc(c.subtitle||'')+'<br><span class="muted">'+esc(c.venueName||'')+', '+esc(c.venueAddress||'')+' · '+fmt(c.startDate)+' – '+fmt(c.endDate)+'</span><br>Adresa pre účastníkov: <code>'+location.origin+'/api/program</code> (v aplikácii stačí zadať <code>'+location.host+'</code>)</p>':'<p class="muted">Program ešte nebol publikovaný — publikujte ho z macOS aplikácie (Server a push → Publikovať) alebo importujte z webu nižšie.</p>';
 document.getElementById('regs').innerHTML=(o.registrations||[]).length?o.registrations.map(r=>'<details><summary><b>'+esc(r.sessionTitle)+'</b> <span class="muted">'+fmt(r.start)+'</span> — prihlásených '+r.registered+(r.capacity!=null?'/'+r.capacity:'')+(r.waitlisted?' · čaká '+r.waitlisted:'')+'</summary><table><tr><th>Meno</th><th>E-mail</th><th>Skupina</th><th>Stav</th><th>Aktualizované</th></tr>'+r.entries.map(e=>'<tr><td>'+esc(e.name||'(bez mena)')+'</td><td>'+esc(e.email)+'</td><td>'+esc(e.group)+'</td><td><span class="tag">'+esc(e.status)+'</span></td><td>'+fmt(e.updatedAt)+'</td></tr>').join('')+'</table></details>').join(''):'<p class="muted">Zatiaľ žiadne prihlášky.</p>';
 document.getElementById('devices').innerHTML=dev.length?'<table><tr><th>Meno</th><th>Platforma</th><th>Skupina</th><th>Push</th><th>Verzia appky</th><th>Naposledy</th></tr>'+dev.map(d=>'<tr><td>'+esc(d.name||'—')+'</td><td>'+esc(d.platform)+'</td><td>'+esc(d.group||'')+'</td><td>'+(d.push?'<span class="ok">áno</span>':'<span class="muted">nie</span>')+'</td><td>'+esc(d.appVersion)+'</td><td>'+fmt(d.lastSeen)+'</td></tr>').join('')+'</table>':'<p class="muted">Zatiaľ sa nepripojilo žiadne zariadenie. Účastník zadá v aplikácii (Nastavenia → Zdroj programu) adresu '+esc(location.host)+'.</p>';
 document.getElementById('pushlog').innerHTML=(o.pushLog||[]).length?'<table><tr><th>Kedy</th><th>Typ</th><th>Nadpis</th><th>Text</th><th>Odoslané</th><th>Zlyhalo</th></tr>'+o.pushLog.map(p=>'<tr><td>'+fmt(p.at)+'</td><td>'+esc(p.kind)+'</td><td>'+esc(p.title)+'</td><td>'+esc(p.body)+'</td><td>'+p.sent+'</td><td>'+(p.failed?'<span class="bad">'+p.failed+' '+esc(p.detail||'')+'</span>':'0')+'</td></tr>').join('')+'</table>':'<p class="muted">Zatiaľ nič.</p>';
 document.getElementById('audit').innerHTML='<table>'+(o.audit||[]).map(a=>'<tr><td>'+fmt(a.at)+'</td><td>'+esc(a.action)+'</td><td>'+esc(a.detail)+'</td></tr>').join('')+'</table>';
}
async function sendPush(){const el=document.getElementById('pushres');el.textContent='…';try{const r=await api('/api/admin/push',{method:'POST',body:JSON.stringify({title:document.getElementById('ptitle').value,body:document.getElementById('pbody').value,group:document.getElementById('pgroup').value||null})});el.innerHTML='<span class="ok">odoslané '+r.sent+'</span>'+(r.failed?' <span class="bad">zlyhalo '+r.failed+'</span>':'')+(r.message?' <span class="bad">'+esc(r.message)+'</span>':'');refresh()}catch(e){el.innerHTML='<span class="bad">'+esc(e.message)+'</span>'}}
async function purge(){const el=document.getElementById('purgeres');if(!confirm('Naozaj vymazať zoznam účastníkov, zariadenia, prihlášky a odoslané push? Server si najprv urobí zálohu.'))return;if(prompt('Napíšte VYMAZAŤ pre potvrdenie:')!=='VYMAZAŤ')return;el.textContent='…';try{const r=await api('/api/admin/purge',{method:'POST',body:'{}'});el.innerHTML='<span class="ok">hotovo — účastníci '+r.deleted.attendees+', zariadenia '+r.deleted.devices+', prihlášky '+r.deleted.registrations+' · záloha '+esc(r.backup)+'</span>';refresh()}catch(e){el.innerHTML='<span class="bad">'+esc(e.message)+'</span>'}}
if(T){show()}
</script></body></html>"""


def admin_page(h, q):
    h._send_bytes(200, ADMIN_HTML.encode("utf-8"), "text/html; charset=utf-8")


def public_base_url(h):
    """Adresa, cez ktorú klient prišiel (Funnel posiela Host aj X-Forwarded-Proto)."""
    host = h.headers.get("X-Forwarded-Host") or h.headers.get("Host") or "127.0.0.1:%d" % PORT
    proto = h.headers.get("X-Forwarded-Proto") or ("https" if host.endswith(".ts.net") else "http")
    return "%s://%s" % (proto, host)


def root(h, q):
    meta = program_meta()
    html = ("<!doctype html><meta charset='utf-8'><title>Congressa server</title><body style='font-family:-apple-system,sans-serif;padding:30px'>"
            "<h1>Congressa server beží</h1><p>Konferencia: <b>%s</b> (verzia programu %s)</p>"
            "<p>Účastník zadá v aplikácii Congressa adresu: <code>%s</code></p><p><a href='/admin'>Admin dashboard</a> · <a href='/api/health'>health</a></p></body>"
            % (meta["name"] if meta else "žiadny publikovaný program", meta["version"] if meta else "—", public_base_url(h)))
    h._send_bytes(200, html.encode("utf-8"), "text/html; charset=utf-8")


ROUTES = [
    ("GET", r"/", root),
    ("GET", r"/api/health", health),
    ("GET", r"/api/program", get_program),
    ("GET", r"/api/program\.json", get_program),
    ("POST", r"/api/verify-code", verify_code),
    ("POST", r"/api/devices", register_device),
    ("DELETE", r"/api/devices/([^/]+)", delete_device),
    ("POST", r"/api/registrations", submit_registration),
    ("GET", r"/api/registrations", list_registrations),
    ("PUT", r"/api/admin/program", admin_put_program),
    ("GET", r"/api/admin/attendees", admin_get_attendees),
    ("PUT", r"/api/admin/attendees", admin_put_attendees),
    ("GET", r"/api/admin/registrations", admin_registrations),
    ("GET", r"/api/admin/registrations\.csv", admin_registrations_csv),
    ("GET", r"/api/admin/devices", admin_devices),
    ("POST", r"/api/admin/push", admin_push),
    ("GET", r"/api/admin/push-log", admin_push_log),
    ("POST", r"/api/admin/import-ai", admin_import_ai),
    ("POST", r"/api/import-ai", public_import_ai),
    ("GET", r"/api/admin/overview", admin_overview),
    ("GET", r"/api/admin/export-db", admin_export_db),
    ("POST", r"/api/admin/purge", admin_purge),
    ("GET", r"/admin", admin_page),
    ("GET", r"/admin/", admin_page),
]


# ----------------------------------------------------------------------------------------------
# Zálohy a štart
# ----------------------------------------------------------------------------------------------

def backup_database_once():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    dst = os.path.join(BACKUP_DIR, "congressa-%s.db" % datetime.now().strftime("%Y-%m-%d"))
    if not os.path.exists(dst) and os.path.exists(DB_PATH):
        consistent_db_copy(dst)
    return dst


def apply_retention():
    """Zmaže push_log a audit staršie ako RETENTION_DAYS (ochrana osobných údajov; tabuľky by inak rástli donekonečna)."""
    if RETENTION_DAYS <= 0:
        return 0
    cutoff = (datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)).isoformat(timespec="seconds").replace("+00:00", "Z")
    conn = db()
    n = conn.execute("DELETE FROM push_log WHERE at < ?", (cutoff,)).rowcount
    n += conn.execute("DELETE FROM audit WHERE at < ? AND action != 'purge'", (cutoff,)).rowcount
    conn.commit()
    return n


def backup_mail_enabled():
    return bool(BACKUP_EMAIL and SMTP_HOST and SMTP_USER and SMTP_PASSWORD)


def mail_backup_once(path):
    """Pošle dennú zálohu e-mailom. Jeden deň = jeden e-mail; stav drží súbor .posledny-email."""
    if not backup_mail_enabled() or not os.path.exists(path):
        return False
    marker = os.path.join(BACKUP_DIR, ".posledny-email")
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        if os.path.exists(marker) and open(marker).read().strip() == today:
            return False
    except Exception:  # noqa
        pass
    import smtplib
    from email.message import EmailMessage

    meta = program_meta()
    msg = EmailMessage()
    msg["Subject"] = "Congressa — záloha databázy %s" % today
    msg["From"] = SMTP_USER
    msg["To"] = BACKUP_EMAIL
    msg.set_content(
        "Denná záloha servera Congressa.\n\n"
        "Konferencia: %s\nZariadenia: %d\nVeľkosť zálohy: %.1f kB\n\n"
        "Súbor obnovíte tak, že ho premenujete na congressa.db a nahradíte ním databázu na serveri "
        "(server predtým zastavte)."
        % (meta["name"] if meta else "zatiaľ nepublikovaná",
           db().execute("SELECT COUNT(*) c FROM devices").fetchone()["c"],
           os.path.getsize(path) / 1024.0)
    )
    with open(path, "rb") as f:
        msg.add_attachment(f.read(), maintype="application", subtype="octet-stream",
                           filename=os.path.basename(path))
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60) as smtp:
        smtp.starttls()
        smtp.login(SMTP_USER, SMTP_PASSWORD)
        smtp.send_message(msg)
    with open(marker, "w") as f:
        f.write(today)
    print("Záloha odoslaná e-mailom na %s" % BACKUP_EMAIL, flush=True)
    return True


def start_backup_thread():
    def loop():
        while True:
            try:
                path = backup_database_once()
                apply_retention()
                try:
                    mail_backup_once(path)
                except Exception as e:  # noqa
                    print("Záloha e-mailom: chyba", e, file=sys.stderr)
            except Exception as e:  # noqa
                print("Záloha: chyba", e, file=sys.stderr)
            time.sleep(6 * 3600)
    threading.Thread(target=loop, daemon=True, name="congressa-backup").start()


def main():
    init_schema()
    start_backup_thread()
    start_scheduler()
    meta = program_meta()
    print("=" * 62)
    print("  Congressa server %s (build %s)  —  port %d" % (SERVER_VERSION, BUILD_ID, PORT))
    print("  Program:    %s" % ("%s (v%d)" % (meta["name"], meta["version"]) if meta else "zatiaľ nepublikovaný"))
    # Heslo sa vypíše len do interaktívneho terminálu — pod launchd ide výstup do server.log, ktorý sa posiela pri riešení problémov.
    shown = (ADMIN_TOKEN if sys.stdout.isatty() else "(je v .env, CONGRESSA_ADMIN_TOKEN)") if ADMIN_TOKEN else "NENASTAVENÉ — admin vypnutý"
    print("  Admin:      http://127.0.0.1:%d/admin   (heslo: %s)" % (PORT, shown))
    print("  Push (APNs): %s" % ("zapnutý, %s, topic %s" % (APNS_ENV, APNS_TOPIC) if push_enabled() else "vypnutý — doplňte CONGRESSA_APNS_KEY_FILE / KEY_ID / TEAM_ID do .env"))
    print("  AI import:  %s" % ("zapnutý (%s)%s" % (AI_MODEL, ", verejne pre účastníkov (limit %d/deň/IP)" % PUBLIC_AI_DAILY_LIMIT if PUBLIC_AI else "") if AI_API_KEY else "vypnutý — voliteľne CONGRESSA_AI_API_KEY do .env"))
    print("  Databáza:   %s" % DB_PATH)
    print("  Zálohy:     %s%s" % (BACKUP_DIR, ", e-mailom na %s" % BACKUP_EMAIL if backup_mail_enabled() else ""))
    print("=" * 62, flush=True)
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    server.daemon_threads = True
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer ukončený.")


if __name__ == "__main__":
    main()
