#!/bin/bash
# Congressa – JEDNO rozkliknutie a beží všetko (inštalácia na správne miesto + server + autostart
# + verejná adresa). Dá sa spúšťať opakovane, nič nepokazí.
#
#   1. ak balík nie je v cieľovom priečinku (~/Congressa_server), skopíruje sa tam a pokračuje odtiaľ,
#   2. skontroluje python3 (macOS 12+: Command Line Tools) a .env (vytvorí ho, vygeneruje admin heslo),
#   3. nainštaluje/obnoví autostart (launchd LaunchAgent) – server sa spúšťa sám po prihlásení
#      a po páde sa reštartne; beží pod `caffeinate`, takže Mac nezaspí,
#   4. spustí server a počká, kým odpovedá /api/health,
#   5. ak je nainštalovaný Tailscale, zapne Funnel – stabilná verejná HTTPS adresa,
#   6. vypíše adresy pre aplikáciu účastníkov (iPhone aj Android) a Mac administráciu + admin heslo.
#
# Po výpadku prúdu alebo siete: stačí sa prihlásiť do Macu – všetko nabehne samo.
# Keby nie, rozklikni tento súbor znova.

set -u
SRC="$(cd "$(dirname "$0")" && pwd)"
TARGET="${CONGRESSA_HOME:-$HOME/Congressa_server}"
LABEL="sk.sikuta.Congressa.server"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
PORT_DEFAULT=8001

echo "══════════════════════════════════════════════════"
echo "  CONGRESSA SERVER – štart"
echo "══════════════════════════════════════════════════"

# ---- 1. Inštalácia na správne miesto ----------------------------------------------
if [ "$SRC" != "$TARGET" ]; then
    echo "📦 Inštalujem balík do: $TARGET"
    mkdir -p "$TARGET"
    # Skopíruj program a pomocné súbory; NIKDY neprepíš .env, databázu, zálohy ani APNs kľúč, ktoré tam už sú.
    for f in congressa_server.py server_daemon.sh START_CONGRESSA.command .env.example NAVOD_DRUHY_MAC.md PRECITAJ_MA.txt CLAUDE_SERVER_BRIEF.md; do
        [ -f "$SRC/$f" ] && cp "$SRC/$f" "$TARGET/$f"
    done
    mkdir -p "$TARGET/apns"
    [ -f "$SRC/apns/PRECITAJ_MA.txt" ] && cp "$SRC/apns/PRECITAJ_MA.txt" "$TARGET/apns/"
    for k in "$SRC"/apns/*.p8; do [ -f "$k" ] && [ ! -f "$TARGET/apns/$(basename "$k")" ] && cp "$k" "$TARGET/apns/"; done
    [ -f "$SRC/.env" ] && [ ! -f "$TARGET/.env" ] && cp "$SRC/.env" "$TARGET/.env"
    [ -f "$SRC/congressa.db" ] && [ ! -f "$TARGET/congressa.db" ] && cp "$SRC/congressa.db" "$TARGET/congressa.db"
    chmod +x "$TARGET/START_CONGRESSA.command" "$TARGET/server_daemon.sh"
    # Zástupca na ploche, nech je štart vždy poruke.
    ln -sf "$TARGET/START_CONGRESSA.command" "$HOME/Desktop/START_CONGRESSA.command" 2>/dev/null || true
    echo "✅ Nainštalované. Odteraz používaj: $TARGET/START_CONGRESSA.command (alias je aj na ploche)."
    cd "$TARGET" || exit 1
else
    cd "$SRC" || exit 1
fi
DIR="$(pwd)"

# ---- 2. Kontroly -------------------------------------------------------------------
if ! command -v python3 >/dev/null 2>&1 || ! python3 -c "import sqlite3" >/dev/null 2>&1; then
    echo ""
    echo "⚠️  Python3 nie je nainštalovaný. Teraz vyskočí okno 'command line developer tools'"
    echo "   – klikni Inštalovať (~5 min) a potom tento súbor rozklikni znova."
    xcode-select --install >/dev/null 2>&1
    read -r -p "Stlač Enter na ukončenie…" _
    exit 1
fi

if [ ! -f .env ]; then
    cp .env.example .env
    echo "ℹ️  Vytvoril som .env (nastavenia servera)."
fi
set_env_var() {
    local key="$1" value="$2"
    if grep -q "^${key}=" .env; then
        awk -v k="$key" -v v="$value" -F= 'BEGIN{OFS="="} $1==k{$0=k"="v} {print}' .env > .env.tmp && mv .env.tmp .env
    else
        echo "${key}=${value}" >> .env
    fi
}
ADMIN_TOKEN="$(grep -E '^CONGRESSA_ADMIN_TOKEN=' .env | head -1 | cut -d= -f2-)"
if [ -z "$ADMIN_TOKEN" ]; then
    ADMIN_TOKEN="$(openssl rand -hex 16)"
    set_env_var CONGRESSA_ADMIN_TOKEN "$ADMIN_TOKEN"
    echo "🔑 Vygeneroval som admin heslo a uložil ho do .env."
fi
PORT="$(grep -E '^PORT=' .env | head -1 | cut -d= -f2)"
PORT="${PORT:-$PORT_DEFAULT}"
# Verejný https port Funnelu: 443 (adresa bez portu) | 8443 | 10000.
# Ak na Macu beží viac projektov, každý potrebuje vlastný uzol Tailscale (CONGRESSA_TS_SOCKET),
# inak si musia porty rozdeliť: 443 pre jeden, 8443 pre druhý.
PUBLIC_HTTPS_PORT="$(grep -E '^CONGRESSA_PUBLIC_HTTPS_PORT=' .env | head -1 | cut -d= -f2-)"
PUBLIC_HTTPS_PORT="${PUBLIC_HTTPS_PORT:-443}"
# Vlastný uzol Tailscale (viac projektov na jednom Macu). Prázdne = systémový tailscaled.
TS_SOCKET="$(grep -E '^CONGRESSA_TS_SOCKET=' .env | head -1 | cut -d= -f2-)"
APNS_KEY="$(grep -E '^CONGRESSA_APNS_KEY_FILE=' .env | head -1 | cut -d= -f2-)"
if [ -z "$APNS_KEY" ]; then
    P8="$(ls apns/*.p8 2>/dev/null | head -1)"
    if [ -n "$P8" ]; then
        KEY_ID="$(basename "$P8" .p8 | sed 's/^AuthKey_//')"
        set_env_var CONGRESSA_APNS_KEY_FILE "$P8"
        [ -z "$(grep -E '^CONGRESSA_APNS_KEY_ID=' .env | cut -d= -f2-)" ] && set_env_var CONGRESSA_APNS_KEY_ID "$KEY_ID"
        echo "🔔 Našiel som APNs kľúč $P8 (Key ID $KEY_ID) – doplnený do .env."
    fi
fi

# ---- 3. Autostart (launchd) – plist sa generuje s aktuálnou cestou --------------------
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>$LABEL</string>
    <key>ProgramArguments</key>
    <array><string>/bin/bash</string><string>$DIR/server_daemon.sh</string></array>
    <key>WorkingDirectory</key><string>$DIR</string>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>ThrottleInterval</key><integer>5</integer>
    <key>StandardOutPath</key><string>$DIR/server.log</string>
    <key>StandardErrorPath</key><string>$DIR/server.log</string>
</dict>
</plist>
PLISTEOF
chmod +x server_daemon.sh 2>/dev/null
launchctl unload "$PLIST" >/dev/null 2>&1
launchctl load -w "$PLIST"
echo "✅ Autostart nainštalovaný (server sa spustí sám po každom prihlásení, po páde sa reštartne)."

# ---- 3b. Nezaspávanie + automatický štart po výpadku prúdu (raz, vyžaduje heslo správcu) ----------
# caffeinate v server_daemon.sh drží Mac bdelý; pmset je poistka: nikdy nespať, po výpadku prúdu sa
# sám zapnúť (autorestart), po zamrznutí sa reštartovať (Mac Pro / Mac mini). Nastaví sa raz.
if pmset -g custom 2>/dev/null | grep -qE '^\s*sleep\s+0' && pmset -g 2>/dev/null | grep -qE 'autorestart\s+1'; then
    echo "✅ Mac nezaspí a po výpadku prúdu sa sám zapne (pmset)."
else
    echo ""
    echo "🔌 Nastavím, aby Mac NIKDY nezaspal a po výpadku prúdu sa SÁM ZAPOL (pmset)."
    echo "   Terminál teraz vypýta heslo správcu tohto Macu (písanie hesla nevidno – normálne)."
    if sudo -p "   Heslo správcu: " pmset -a sleep 0 disksleep 0 autorestart 1 womp 1 ttyskeepawake 1 2>/dev/null; then
        sudo pmset -a displaysleep 15 >/dev/null 2>&1 || true
        echo "✅ Hotovo: nikdy nespať, po výpadku prúdu automaticky zapnúť, displej sa vypne po 15 min."
    else
        echo "⚠️  Nenastavené (zlé heslo alebo zrušené). Ručne: Nastavenia systému → Šetrenie energie →"
        echo "   „Zabrániť automatickému uspaniu“ = ZAPNÚŤ, „Spustiť automaticky po výpadku napájania“ = ZAPNÚŤ."
    fi
fi
# Aby server nabehol po reštarte BEZ toho, aby niekto zadal heslo: automatické prihlásenie.
AUTOLOGIN="$(defaults read /Library/Preferences/com.apple.loginwindow autoLoginUser 2>/dev/null || true)"
if [ -n "$AUTOLOGIN" ]; then
    echo "✅ Automatické prihlásenie po štarte: $AUTOLOGIN (server nabehne aj po reštarte bez zásahu)."
else
    echo "ℹ️  Po reštarte Macu server nabehne až po prihlásení používateľa. Aby nabehol SÁM:"
    echo "   Nastavenia systému → Používatelia a skupiny → Automaticky prihlásiť ako: $(whoami)"
    echo "   (vyžaduje vypnutý FileVault: Nastavenia → Súkromie a bezpečnosť → FileVault = Vypnúť)."
fi

# ---- 4. Počkaj na server -----------------------------------------------------------------
echo -n "⏳ Čakám na server (port $PORT) "
OK=""
for _ in $(seq 1 30); do
    if curl -s --max-time 2 "http://127.0.0.1:$PORT/api/health" | grep -q '"ok"'; then OK=1; break; fi
    echo -n "."; sleep 1
done
echo ""
if [ -n "$OK" ]; then
    echo "✅ Server beží a odpovedá."
    HEALTH="$(curl -s --max-time 2 "http://127.0.0.1:$PORT/api/health")"
    echo "$HEALTH" | grep -q '"pushEnabled": true' && echo "✅ Push notifikácie (APNs): zapnuté." || echo "⚠️  Push notifikácie: VYPNUTÉ – ulož AuthKey_XXXXXXXXXX.p8 do apns/ a doplň CONGRESSA_APNS_TEAM_ID do .env (pozri NAVOD_DRUHY_MAC.md), potom rozklikni znova."
else
    echo "❌ Server neodpovedá – posledné riadky logu:"
    tail -8 server.log 2>/dev/null
    read -r -p "Stlač Enter na ukončenie…" _
    exit 1
fi

# ---- 5. Tailscale Funnel (verejná HTTPS adresa) --------------------------------------------
TS="$(command -v tailscale || true)"
for CAND in /usr/local/bin/tailscale /opt/homebrew/bin/tailscale "/Applications/Tailscale.app/Contents/MacOS/Tailscale"; do
    [ -n "$TS" ] && break
    [ -x "$CAND" ] && TS="$CAND"
done
FUNNEL_URL=""
if [ -n "$TS" ]; then
    if [ -n "$TS_SOCKET" ]; then TSC="$TS --socket=$TS_SOCKET"; else TSC="$TS"; fi
    FUNNEL_OUT="$($TSC funnel --bg --https="$PUBLIC_HTTPS_PORT" "$PORT" 2>&1)" || true
    if [ "$PUBLIC_HTTPS_PORT" = "443" ]; then
        FUNNEL_URL="$($TSC funnel status 2>/dev/null | grep -oE 'https://[^ :]*\.ts\.net' | head -1)"
    else
        FUNNEL_URL="$($TSC funnel status 2>/dev/null | grep -oE "https://[^ ]*\.ts\.net:$PUBLIC_HTTPS_PORT" | head -1)"
    fi
    if [ -n "$FUNNEL_URL" ]; then
        echo "✅ Tailscale Funnel beží."
    else
        echo "⚠️  Tailscale je nainštalovaný, ale Funnel sa nepodarilo zapnúť:"
        echo "$FUNNEL_OUT" | sed 's/^/   /'
        echo "   • appka Tailscale musí bežať a byť prihlásená (ikona v hornej lište),"
        echo "   • na login.tailscale.com → DNS zapni MagicDNS + HTTPS Certificates,"
        echo "   • ak je vyššie odkaz login.tailscale.com/f/…, otvor ho a potvrď; potom rozklikni znova."
    fi
else
    echo "ℹ️  Tailscale nie je nainštalovaný – appka sa pripojí len z tej istej Wi-Fi."
    echo "   Pre prístup odkiaľkoľvek: https://tailscale.com/download → prihlásiť → rozkliknúť tento súbor znova."
fi

# ---- 6. Súhrn ---------------------------------------------------------------------------------
LAN_IP="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || true)"
echo ""
echo "══════════════════════════════════════════════════"
echo "  HOTOVO – adresy pre Congressa:"
[ -n "$FUNNEL_URL" ] && echo "  • ODKIAĽKOĽVEK (účastníci, odporúčané):  $FUNNEL_URL"
[ -n "$LAN_IP" ]     && echo "  • Tá istá Wi-Fi:                         http://$LAN_IP:$PORT"
echo "  • Admin dashboard:                       $( [ -n "$FUNNEL_URL" ] && echo "$FUNNEL_URL" || echo "http://${LAN_IP:-127.0.0.1}:$PORT")/admin"
echo "  • Admin heslo (Mac appka → Server a push): $ADMIN_TOKEN"
echo "══════════════════════════════════════════════════"
echo ""
echo "Toto okno môžeš zavrieť – server beží ďalej na pozadí (launchd + caffeinate)."
read -r -p "Stlač Enter na ukončenie…" _
