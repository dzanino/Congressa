# Brief pre Claude na tomto Macu (Congressa server)

> **Pre Jána:** otvor Claude Desktop na tomto počítači a napíš:
> *„Prečítaj si CLAUDE_SERVER_BRIEF.md v ~/Congressa_server a pokračuj podľa neho.“*

## 1. S kým pracuješ

MUDr. Ján Šikuta, PhD., súdny lekár — **nie je programátor**. Komunikuj po slovensky, krok za krokom,
príkazy dávaj celé a hotové na skopírovanie. Nikdy si nepýtaj heslá ani obsah `.env` do chatu.

## 2. Čo je Congressa

Aplikácia s programom konferencie: účastník ju má na iPhone alebo Androide (rovnaké API; Android zatiaľ bez push — oznamy si stiahne pri otvorení a priebežne, keď je appka na obrazovke), organizátor spravuje program na Macu.
Program funguje **offline** — účastník si ho naimportuje z webu alebo PDF konferencie, skontroluje,
schváli a odvtedy mu chodia lokálne upozornenia. Aplikácia je **zadarmo**, monetizácia je cez nepovinné
príspevky. Vývoj beží na hlavnom Macu Jána (repozitár `Claude_Projekty/Congressa`).

**Tento Mac (Mac Pro) je server. Kód aplikácie sa tu neupravuje.** Server je nadstavba, ktorá organizátorovi
pridá to, čo samotná appka nevie: push notifikácie pred každým bodom programu, prihlášky na večeru či výlet
s kapacitou a čakacou listinou, prezenčné listiny a hromadné oznamy.

## 3. Čo tu beží

| Vec | Kde |
|---|---|
| Server (jeden súbor, Python stdlib + SQLite) | `~/Congressa_server/congressa_server.py` |
| Spúšťač a inštalátor (dvojklik) | `~/Congressa_server/START_CONGRESSA.command` |
| Démon pre launchd (`caffeinate`, Funnel) | `~/Congressa_server/server_daemon.sh` |
| Nastavenia vrátane tajomstiev | `~/Congressa_server/.env` |
| Databáza a zálohy | `~/Congressa_server/congressa.db`, `backups/` |
| APNs kľúč | `~/Congressa_server/apns/AuthKey_XXXXXXXXXX.p8` |
| Logy | `~/Congressa_server/server.log`, `funnel.log` |
| Autostart po prihlásení | `~/Library/LaunchAgents/sk.sikuta.Congressa.server.plist` |

Port podľa `.env` (predvolene **8001**). Stav: `curl -s http://127.0.0.1:8001/api/health`.
Administrácia v prehliadači: `http://127.0.0.1:8001/admin` (heslo = `CONGRESSA_ADMIN_TOKEN` z `.env`).
Verejná adresa ide cez **Tailscale Funnel** a musí byť **https** — iOS nepustí nezabezpečené spojenie.

**Ak na Macu beží viac projektov** (tu Congressa + Carpoolka), každý potrebuje **vlastný uzol Tailscale**,
lebo Funnel viaže adresu na názov uzla. Congressa má preto vlastný `tailscaled` v userspace režime
(LaunchAgent `sk.sikuta.Congressa.tailscaled`, stav v `~/Congressa_server/tailscale/`) a v `.env` má
`CONGRESSA_TS_SOCKET`. **Každé volanie `tailscale` musí ísť cez `--socket=$CONGRESSA_TS_SOCKET`**,
inak nastavíš Funnel tomu druhému projektu. Prázdna hodnota = jeden projekt, systémový tailscaled.

| Projekt | Uzol | Verejná adresa | Lokálny port |
|---|---|---|---|
| Congressa | `congressa` (vlastný, userspace) | `https://congressa.tail74360e.ts.net` | 8001 |
| Carpoolka | `carpoolka-server` (systémový) | `https://carpoolka-server.tail74360e.ts.net` | 8000 |

Žiadne `pip install`. Server musí ostať kompatibilný s **Python 3.8** (bez `zoneinfo`, bez `match`,
bez zápisu typov `X | Y`). Ak by si to porušil, na tomto Macu prestane fungovať.

## 4. Ako sa to spúšťa a reštartuje

```bash
bash ~/Congressa_server/START_CONGRESSA.command          # inštalácia aj reštart, je to idempotentné
launchctl kickstart -k gui/$(id -u)/sk.sikuta.Congressa.server   # len reštart démona
tail -50 ~/Congressa_server/server.log                   # čo sa deje
launchctl list | grep congressa                           # beží vôbec?
tailscale funnel status                                   # verejná adresa
```

## 5. Najčastejšie úlohy

1. **Server neodpovedá.** Pozri log, potom `launchctl list | grep congressa`, potom spusti START znova.
   Ak port obsadí niečo iné, uvidíš to v logu.
2. **Nechodia push.** V `/api/health` musí byť `"pushEnabled": true`. Ak nie, chýba niektorý riadok
   `CONGRESSA_APNS_*` v `.env` alebo súbor `.p8` — postup je v `APNS_KLUC.md`. Ak push odchádza, ale
   nedôjde: `/admin` → Odoslané push → stĺpec *Zlyhalo*. `BadDeviceToken` = zlé prostredie (production
   pre TestFlight a App Store, sandbox pre build z Xcode) alebo zlý topic. `InvalidProviderToken` = zlý
   kľúč, Key ID, Team ID, alebo rozhodené hodiny Macu.
3. **Zálohy.** Server zálohuje databázu do `backups/` každých 6 hodín. Ak sú v `.env` vyplnené
   `CONGRESSA_BACKUP_EMAIL` a SMTP údaje, pošle zálohu raz denne aj e-mailom (pre iCloud treba
   „heslo pre aplikáciu“ z Apple ID). Logy sa pri štarte rotujú nad 2 MB (`server.log.1`).
4. **Nová verzia servera z hlavného Macu.** Rozbaliť nový zip a spustiť START. Prepíše len program,
   databáza, `.env` a `apns/` ostanú nedotknuté.
5. **Organizátor chce publikovať program.** Robí sa to z macOS aplikácie Congressa (Server a push →
   adresa + admin heslo → Publikovať program), nie z tohto servera.
6. **Konferencia skončila.** `/admin` → „Vymazať údaje účastníkov“ (alebo v Mac aplikácii „Ukončiť
   konferenciu“): server si urobí zálohu `backups/pred-purge-….db` a zmaže účastníkov, zariadenia
   a prihlášky. Program ostane. Odoslané push a audit staršie ako 180 dní sa mažú samy.
7. **Admin heslo „zablokované“ (429).** Po 10 zlých pokusoch z jednej IP server na 10 minút odmieta
   aj správne heslo — počkať. V `/admin` → Audit sú riadky `admin-auth-failed` s IP.
8. **Organizátor nevie overiť prístupový kód v appke.** Od servera 1.1.0 kód overuje `POST /api/verify-code`,
   aplikácia musí byť aspoň vo verzii z `/api/health` → `minAppVersion` (iOS 2.6, Android 1.4).

## 6. Čo nikdy nerob

- Neposielaj a necommituj `.env`, `congressa.db`, priečinky `apns/` a `tailscale/` (súkromný kľúč uzla)
  ani obsah `server.log` — sú v nich tajomstvá a osobné údaje účastníkov.
- Nepridávaj závislosti cez pip a nemeň server na framework.
- Nemaž `congressa.db`. Ak treba čistý stav, najprv `sqlite3 congressa.db ".backup backups/rucna-zaloha-$(date +%F).db"`
  (databáza beží v režime WAL — obyčajné `cp` môže vynechať posledné zápisy v `congressa.db-wal`).
- Needituj tu zdrojový kód aplikácie; opravy patria do repozitára na hlavnom Macu.

## 7. Kam sa pozrieť ďalej

- `NAVOD_DRUHY_MAC.md` — inštalácia krok za krokom pre laika, vrátane autoboot a nezaspávania.
- `APNS_KLUC.md` — ako vytvoriť APNs kľúč v Apple Developer a čo doplniť do `.env`.
- `.env.example` — všetky premenné aj s vysvetlením.
- `PRECITAJ_MA.txt` — najkratšia verzia pre toho, kto len rozbalí zip.
- `sk.sikuta.Congressa.tailscaled.plist.priklad` — LaunchAgent vlastného uzla Tailscale (len ak na Macu
  beží viac projektov). Kopíruje sa do `~/Library/LaunchAgents/` bez prípony `.priklad`.
- `LOKALNE_NASTAVENIE.md` **na serveri** (nie je v balíku, prežije aktualizáciu) — čo je na tomto
  konkrétnom Macu neštandardné.
