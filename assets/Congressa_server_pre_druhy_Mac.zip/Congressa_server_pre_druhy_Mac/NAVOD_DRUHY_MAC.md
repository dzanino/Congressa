# Congressa server na druhom Macu (Mac Pro „server“) – návod k tomuto balíku

Tento priečinok obsahuje **všetko na spustenie Congressa servera** na druhom Macu. Cieľové
umiestnenie si skript spraví sám: **`/Users/<používateľ>/Congressa_server`** (Domov → Congressa_server).

## Čo je v balíku

| Súbor | Načo je |
|---|---|
| `START_CONGRESSA.command` | **Jediné, čo rozklikávaš.** Nainštaluje balík do `~/Congressa_server`, vytvorí `.env` s admin heslom, nainštaluje autostart (launchd), nastaví nezaspávanie a automatické zapnutie po výpadku prúdu, spustí server, zapne Tailscale Funnel a vypíše adresy. Dá sa spúšťať opakovane. |
| `congressa_server.py` | Samotný server (Python, bez závislostí). |
| `server_daemon.sh` | Interný spúšťač pre autostart (`caffeinate` + Funnel) – nespúšťaš ručne. |
| `.env.example` | Vzor nastavení; skutočný `.env` vznikne pri prvom spustení. |
| `apns/` | Sem patrí kľúč `AuthKey_XXXXXXXXXX.p8` pre push notifikácie (skript ho nájde sám). |
| `PRECITAJ_MA.txt` | Najkratší postup. `CLAUDE_SERVER_BRIEF.md` – kontext pre Claude na tomto Macu. |

## Prvé spustenie (raz, ~10 minút)

1. **Prenes balík** na druhý Mac (AirDrop / USB / zip) – hocikam, napr. do Stiahnutých.
2. **Push notifikácie:** do priečinka `apns/` v balíku vlož `AuthKey_XXXXXXXXXX.p8`
   (Apple Developer → Keys). Ak ho ešte nemáš, server pôjde aj bez neho – push doplníš neskôr.
3. **Rozklikni `START_CONGRESSA.command`** (prvý raz: pravý klik → Otvoriť → Otvoriť).
   - Ak vypýta „command line developer tools“ → Inštalovať (~5 min) → rozklikni znova.
   - Ak vypýta **heslo správcu** – je to na nastavenie „nikdy nespať / zapnúť sa po výpadku prúdu“
     (píše sa naslepo, potvrď Enterom).
   - Ak macOS vypýta, či smie Python prijímať prichádzajúce spojenia → **Povoliť**.
4. Skript vypíše **adresy** a **admin heslo**:
   - adresu zadajú účastníci v aplikácii na iPhone alebo Androide (Nastavenia → Zdroj programu),
     alebo naskenujú QR kód, ktorý ukáže Mac appka (Server a push → QR kód) — kód je rovnaký pre obe platformy,
   - adresu + admin heslo zadáš v Mac aplikácii Congressa → *Server a push* → Publikovať.
5. Ak sa push nezapol (skript to vypíše): otvor `~/Congressa_server/.env` v TextEdite
   (skryté súbory: Cmd+Shift+.) a doplň `CONGRESSA_APNS_TEAM_ID=QS4A9TCFAU` (Team ID z Apple
   Developer) a `CONGRESSA_APNS_ENV=production` (TestFlight/App Store) alebo `sandbox` (build z Xcode).
   Rozklikni START znova.

Na ploche pribudne zástupca `START_CONGRESSA.command` – po čomkoľvek nezvyčajnom (update macOS,
výpadok, pochybnosť) ho rozklikni: všetko skontroluje, spustí a vypíše adresy.

## Po reštarte, výpadku prúdu alebo siete – autoboot

- **Výpadok prúdu:** Mac sa sám zapne (`pmset autorestart`, nastavil START).
- **Po štarte Macu:** server sa spustí sám po prihlásení používateľa (launchd LaunchAgent), po páde
  sa reštartne, beží pod `caffeinate` – Mac nezaspí.
- **Aby nabehol bez toho, aby niekto pri Macu zadal heslo:** Nastavenia systému → Používatelia
  a skupiny → **Automaticky prihlásiť ako: <používateľ servera>**. Vyžaduje vypnutý FileVault
  (Nastavenia → Súkromie a bezpečnosť → FileVault → Vypnúť). START vypíše, či je to nastavené.
- Tailscale sa pripojí sám a Funnel adresa ostáva rovnaká – v aplikáciách sa nič nemení.

## Verejná adresa (účastníci mimo Wi-Fi) – Tailscale Funnel

iOS blokuje `http://` na verejné adresy, preto verejný server musí byť **https**. Tailscale Funnel
dá serveru stabilnú adresu `https://<mac>.<tailnet>.ts.net`, ktorá prežije zmenu IP aj reštart
routra a nepotrebuje presmerovanie portov.

1. Nainštaluj Tailscale (https://tailscale.com/download), otvor ho a prihlás sa.
2. Na https://login.tailscale.com → **DNS**: zapni **MagicDNS** a **HTTPS Certificates**.
3. Rozklikni `START_CONGRESSA.command` – Funnel zapne sám a vypíše adresu. (Prvýkrát môže vypýtať
   potvrdenie v prehliadači – odsúhlas.)

## Kontrola a riešenie problémov

| Čo | Ako |
|---|---|
| Beží server? | Safari na tomto Macu: `http://127.0.0.1:8001/api/health` → `{"status": "ok"…}` |
| Log servera | `~/Congressa_server/server.log` (otvor TextEditom) |
| Push zapnutý? | v `/api/health` je `"pushEnabled": true`; v `/admin` karta Push |
| Funnel adresa | Terminál: `tailscale funnel status` |
| Admin dashboard | `https://…ts.net/admin` (heslo = `CONGRESSA_ADMIN_TOKEN` v `.env`) |
| Zálohy DB | samy: `~/Congressa_server/backups/` (raz za deň); ručne `/admin → Stiahnuť zálohu` |
| Vypnúť server | Terminál: `launchctl unload ~/Library/LaunchAgents/sk.sikuta.Congressa.server.plist` |
| Reštart servera | rozklikni `START_CONGRESSA.command` |

## Aktualizácia servera

Nový balík (zip) rozbaľ a rozklikni jeho `START_CONGRESSA.command` – skopíruje nový
`congressa_server.py` do `~/Congressa_server` (databáza, `.env`, `apns/` a zálohy ostávajú) a reštartne
server.

## Čo je nové v serveri 1.1.0 (14. 9. 2026)

- **Bezpečnosť:** verejný program už neobsahuje odtlačky prístupových kódov (`accessCodes`); aplikácie si kód
  overujú na serveri (`POST /api/verify-code`) — potrebujú Congressa pre iPhone 2.6 / Android 1.4 alebo novšie
  (`/api/health` → `minAppVersion`). Limit veľkosti požiadavky (413), timeout spojenia, admin heslo v konštantnom
  čase + po 10 zlých pokusoch z jednej IP 10 minút blokované (429), heslo sa už nevypisuje do `server.log`.
- **Opravené:** AI import zadaním adresy webu (chýbala funkcia `http_get_text`); server sťahuje len verejné
  http(s) adresy (nie LAN/tailnet/localhost).
- **Prezenčné listiny:** meno zo zoznamu účastníkov má prednosť pred menom z aplikácie; stĺpec „overený kódom“.
- **Ochrana osobných údajov:** `/admin` → *Ukončenie konferencie* → **Vymazať údaje účastníkov** (so zálohou
  `backups/pred-purge-….db`); účastník sa vie odpojiť sám (*Nastavenia → Odpojiť sa od servera*); push log
  a audit staršie ako 180 dní sa mažú (`CONGRESSA_RETENTION_DAYS`).
- **Push:** notifikácie majú expiráciu (pripomienka platí do začiatku bodu — vypnutý telefón ju nedostane
  o 3 hodiny neskôr), bez odznaku na ikone.
- **Databáza** beží v režime WAL; záloha z admina je konzistentná kópia. Pri ručnej obnove zo zálohy zmaž aj
  `congressa.db-wal` a `congressa.db-shm`.
- Po aktualizácii over: `/api/health` → `"serverVersion": "1.1.0"`.

## Čo je nové v serveri 1.1.1 (24. 9. 2026)

- **Skupinu účastníka určuje len server** podľa prístupového kódu. Predtým si ju zariadenie mohlo poslať samo
  a dostávať tak cielené oznamy cudzej skupiny.
- **Kód zo zoznamu účastníkov bez vyplnenej skupiny je platný.** Predtým ho appka odmietla ako neplatný.
- **Zálohy sa upratujú:** `CONGRESSA_BACKUP_KEEP` (predvolene 60 denných; `pred-purge-…` a `pred-1.2.0-…`
  sa nemažú nikdy) a `CONGRESSA_BACKUP_COPY_DIR` — druhá kópia každej dennej zálohy do zadaného priečinka
  (na tomto serveri iCloud Drive → `Congressa_zalohy`).
- **`CONGRESSA_BIND`** — na ktorej adrese server počúva (predvolene `0.0.0.0` kvôli prístupu cez Wi-Fi;
  pri Funneli sa dá zúžiť na `127.0.0.1`).
- Drobnosti: chybný zoznam účastníkov už nič nezmaže, hlavička `Host` sa v HTML escapuje, verejný AI import
  neberie `X-Forwarded-For` od kohokoľvek, pripomienka po páde servera neostane „odoslaná“.

## Čo je nové v serveri 1.2.0 — organizátori a licencie (24. 9. 2026)

Server po novom unesie **viac konferencií naraz**, každú s vlastným účtom.

- **Vlastník servera** = ty, prihlasuje sa heslom `CONGRESSA_ADMIN_TOKEN` z `.env` (nič sa nemení).
- **Organizátor** = účet, ktorý vlastník vytvorí v `/admin` → *Organizátori na tomto serveri* → *Nový organizátor*.
  Dostane **token** (ukáže sa **len raz**, tvar `org-…`) a adresu `https://congressa.tail74360e.ts.net/t/<označenie>`.
  Token a adresu zadá vo svojej Mac aplikácii namiesto admin hesla — **appka sa nemusí meniť**, len tam patrí
  iná adresa a iný token.
- Každý organizátor má **vlastný program, účastníkov, zariadenia, prihlášky a push log** — navzájom o sebe nevedia.
- Tvoja doterajšia konferencia ostáva na **koreňovej adrese** bez `/t/…`; pre účastníkov sa nezmenilo nič.
- Vlastník v `/admin` vidí všetkých organizátorov, ich licencie a aktivitu, vie sa do ich konferencie prepnúť
  (*Otvoriť*), upraviť licenciu, **pozastaviť**, vydať **nový token** alebo účet aj s dátami **zmazať**
  (predtým sa automaticky urobí záloha).

**Licencia** (plán `free` / `trial` / `pro` a dátum „platí do“):

- Po vypršaní beží **ochranná lehota 14 dní**, počas nej funguje všetko.
- Potom organizátor **nemôže** publikovať program, posielať ručné oznamy ani nahrať zoznam účastníkov
  (appka dostane zrozumiteľnú hlášku).
- **Nikdy sa nezablokuje** program pre účastníkov, automatické pripomienky, prihlášky ani čakacia listina —
  **prebiehajúca konferencia vždy dobehne.**
- Vlastník môže publikovať aj do konferencie s vypršanou licenciou.

> **Databáza sa pri prvom štarte 1.2.0 sama prevedie** na novú verziu a je to **nevratné**. Pred inštaláciou
> si urob ručnú zálohu:
> `sqlite3 ~/Congressa_server/congressa.db ".backup ~/Congressa_server/backups/pred-1.2.0-$(date +%F).db"`

## Čo je nové v serveri 1.2.1 (24. 9. 2026)

- **Admin dashboard sa dá používať na iPhone.** Tabuľky sa na úzkej obrazovke menia na karty, stránka
  sa už neposúva do strán a tlačidlá sú dosť veľké na prst.
- **Úprava organizátora je formulár**, nie séria okienok s otázkami.
- V hlavičke `/admin` je vidieť **bežiacu verziu a build servera** (užitočné pri hlásení problému).

## Čo je nové v serveri 1.2.2 (24. 9. 2026)

- Opravené tiché zobrazovanie starého programu pri prepnutí medzi konferenciami na tom istom serveri
  (technicky: ETag programu teraz obsahuje aj označenie konferencie). Prejaví sa to až vtedy, keď
  na serveri beží viac organizátorov — pre účastníkov sa nič nemení a netreba nič robiť.

Po aktualizácii over: `/api/health` → `"serverVersion": "1.2.2"`.
