# Congressa server na druhom Macu (Mac Pro „server“) – návod k tomuto balíku

Tento priečinok obsahuje **všetko na spustenie Congressa servera** na druhom Macu. Cieľové
umiestnenie si skript spraví sám: **`/Users/<používateľ>/Congressa_server`** (Domov → Congressa_server).

## Čo je v balíku

| Súbor | Načo je |
|---|---|
| `START_CONGRESSA.command` | **Jediné, čo rozklikávaš.** Nainštaluje balík do `~/Congressa_server`, vytvorí `.env` s admin heslom, nainštaluje autostart (launchd), nastaví nezaspávanie a automatické zapnutie po výpadku prúdu, spustí server, zapne Tailscale Funnel a vypíše adresy. Dá sa spúšťať opakovane. |
| `congressa_server.py` | Samotný server (Python, bez závislostí). |
| `server_daemon.sh` | Interný spúšťač pre autostart (`caffeinate` + Funnel) – nespúšťaš ručne. |
| `.env.example` | Vzor nastavení; skutočný `.env` vznikne pri prvom spustení. |
| `apns/` | Sem patrí kľúč `AuthKey_XXXXXXXXXX.p8` pre push notifikácie (skript ho nájde sám). |
| `PRECITAJ_MA.txt` | Najkratší postup. `CLAUDE_SERVER_BRIEF.md` – kontext pre Claude na tomto Macu. |

## Prvé spustenie (raz, ~10 minút)

1. **Prenes balík** na druhý Mac (AirDrop / USB / zip) – hocikam, napr. do Stiahnutých.
2. **Push notifikácie:** do priečinka `apns/` v balíku vlož `AuthKey_XXXXXXXXXX.p8`
   (Apple Developer → Keys). Ak ho ešte nemáš, server pôjde aj bez neho – push doplníš neskôr.
3. **Rozklikni `START_CONGRESSA.command`** (prvý raz: pravý klik → Otvoriť → Otvoriť).
   - Ak vypýta „command line developer tools“ → Inštalovať (~5 min) → rozklikni znova.
   - Ak vypýta **heslo správcu** – je to na nastavenie „nikdy nespať / zapnúť sa po výpadku prúdu“
     (píše sa naslepo, potvrď Enterom).
   - Ak macOS vypýta, či smie Python prijímať prichádzajúce spojenia → **Povoliť**.
4. Skript vypíše **adresy** a **admin heslo**:
   - adresu zadajú účastníci v aplikácii na iPhone alebo Androide (Nastavenia → Zdroj programu),
     alebo naskenujú QR kód, ktorý ukáže Mac appka (Server a push → QR kód) — kód je rovnaký pre obe platformy,
   - adresu + admin heslo zadáš v Mac aplikácii Congressa → *Server a push* → Publikovať.
5. Ak sa push nezapol (skript to vypíše): otvor `~/Congressa_server/.env` v TextEdite
   (skryté súbory: Cmd+Shift+.) a doplň `CONGRESSA_APNS_TEAM_ID=QS4A9TCFAU` (Team ID z Apple
   Developer) a `CONGRESSA_APNS_ENV=production` (TestFlight/App Store) alebo `sandbox` (build z Xcode).
   Rozklikni START znova.

Na ploche pribudne zástupca `START_CONGRESSA.command` – po čomkoľvek nezvyčajnom (update macOS,
výpadok, pochybnosť) ho rozklikni: všetko skontroluje, spustí a vypíše adresy.

## Po reštarte, výpadku prúdu alebo siete – autoboot

- **Výpadok prúdu:** Mac sa sám zapne (`pmset autorestart`, nastavil START).
- **Po štarte Macu:** server sa spustí sám po prihlásení používateľa (launchd LaunchAgent), po páde
  sa reštartne, beží pod `caffeinate` – Mac nezaspí.
- **Aby nabehol bez toho, aby niekto pri Macu zadal heslo:** Nastavenia systému → Používatelia
  a skupiny → **Automaticky prihlásiť ako: <používateľ servera>**. Vyžaduje vypnutý FileVault
  (Nastavenia → Súkromie a bezpečnosť → FileVault → Vypnúť). START vypíše, či je to nastavené.
- Tailscale sa pripojí sám a Funnel adresa ostáva rovnaká – v aplikáciách sa nič nemení.

## Verejná adresa (účastníci mimo Wi-Fi) – Tailscale Funnel

iOS blokuje `http://` na verejné adresy, preto verejný server musí byť **https**. Tailscale Funnel
dá serveru stabilnú adresu `https://<mac>.<tailnet>.ts.net`, ktorá prežije zmenu IP aj reštart
routra a nepotrebuje presmerovanie portov.

1. Nainštaluj Tailscale (https://tailscale.com/download), otvor ho a prihlás sa.
2. Na https://login.tailscale.com → **DNS**: zapni **MagicDNS** a **HTTPS Certificates**.
3. Rozklikni `START_CONGRESSA.command` – Funnel zapne sám a vypíše adresu. (Prvýkrát môže vypýtať
   potvrdenie v prehliadači – odsúhlas.)

## Kontrola a riešenie problémov

| Čo | Ako |
|---|---|
| Beží server? | Safari na tomto Macu: `http://127.0.0.1:8001/api/health` → `{"status": "ok"…}` |
| Log servera | `~/Congressa_server/server.log` (otvor TextEditom) |
| Push zapnutý? | v `/api/health` je `"pushEnabled": true`; v `/admin` karta Push |
| Funnel adresa | Terminál: `tailscale funnel status` |
| Admin dashboard | `https://…ts.net/admin` (heslo = `CONGRESSA_ADMIN_TOKEN` v `.env`) |
| Zálohy DB | samy: `~/Congressa_server/backups/` (raz za deň); ručne `/admin → Stiahnuť zálohu` |
| Vypnúť server | Terminál: `launchctl unload ~/Library/LaunchAgents/sk.sikuta.Congressa.server.plist` |
| Reštart servera | rozklikni `START_CONGRESSA.command` |

## Aktualizácia servera

Nový balík (zip) rozbaľ a rozklikni jeho `START_CONGRESSA.command` – skopíruje nový
`congressa_server.py` do `~/Congressa_server` (databáza, `.env`, `apns/` a zálohy ostávajú) a reštartne
server.
