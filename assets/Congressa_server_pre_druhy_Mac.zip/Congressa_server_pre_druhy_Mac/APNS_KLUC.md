# APNs kľúč pre push notifikácie — postup krok za krokom

Kľúč vytvára Apple, nedá sa vygenerovať lokálne. Trvá to ~10 minút a robí sa **raz na tím** (platí pre všetky
vaše aplikácie). Potom už len skopírujete súbor na Mac Pro a doplníte tri riadky do `.env`.

## 1. Vytvorenie kľúča v Apple Developer (5 minút)

1. Otvorte <https://developer.apple.com/account> a prihláste sa účtom, pod ktorým je tím **QS4A9TCFAU**.
2. **Certificates, Identifiers & Profiles** → vľavo **Keys** → tlačidlo **+** (Create a key).
3. **Key Name:** `Congressa APNs` (názov je len pre vás).
4. Zaškrtnite **Apple Push Notifications service (APNs)**.
   - Ak sa objaví **Configure**: zvoľte **Team Scoped (All Topics)** — kľúč potom platí pre všetky vaše appky
     a nemusíte vyberať App ID. (Ak by ste zvolili *Topic Specific*, vyberte App ID `sk.sikuta.Congressa`.)
5. **Continue** → **Register**.
6. **Download** — stiahne sa súbor **`AuthKey_XXXXXXXXXX.p8`**.
   > ⚠️ Stiahnuť sa dá **iba raz**. Ak ho stratíte, kľúč sa musí zrušiť a vytvoriť nový.
7. Na tej istej stránke si poznačte:
   - **Key ID** = tých 10 znakov v názve súboru (`AuthKey_ABCD123456.p8` → `ABCD123456`),
   - **Team ID** = `QS4A9TCFAU` (nájdete ho aj vpravo hore v účte pod menom, alebo v Membership details).

## 2. Prenos na Mac Pro (1 minúta)

- Súbor `AuthKey_XXXXXXXXXX.p8` skopírujte do priečinka **`apns/`** v balíku
  `Congressa_server_pre_druhy_Mac` **ešte pred** prvým rozkliknutím `START_CONGRESSA.command`.
- Ak je server na Mac Pro už nainštalovaný, skopírujte kľúč do **`~/Congressa_server/apns/`**.

`START_CONGRESSA.command` kľúč nájde sám a doplní do `.env` riadky `CONGRESSA_APNS_KEY_FILE`
a `CONGRESSA_APNS_KEY_ID`.

## 3. Doplnenie do `.env` (1 minúta)

Otvorte `~/Congressa_server/.env` v TextEdite (skryté súbory vo Finderi zobrazíte `Cmd + Shift + .`)
a skontrolujte, že tam sú tieto štyri riadky:

```
CONGRESSA_APNS_KEY_FILE=apns/AuthKey_XXXXXXXXXX.p8
CONGRESSA_APNS_KEY_ID=XXXXXXXXXX
CONGRESSA_APNS_TEAM_ID=QS4A9TCFAU
CONGRESSA_APNS_TOPIC=sk.sikuta.Congressa
CONGRESSA_APNS_ENV=production
```

**`CONGRESSA_APNS_ENV`** je jediné, čo sa mení podľa toho, odkiaľ appku máte:
- `production` — aplikácia z **TestFlightu alebo App Store** (to je váš prípad, build 4 už je nahratý),
- `sandbox` — aplikácia nainštalovaná priamo z **Xcode** na pripojený iPhone.

Ak sa pomýlite, push sa neodošle a v logu bude `BadDeviceToken` — vtedy hodnotu prepnite a server reštartujte.

## 4. Reštart a overenie (2 minúty)

1. Rozkliknite **`START_CONGRESSA.command`** znova (alebo v Termináli
   `launchctl kickstart -k gui/$(id -u)/sk.sikuta.Congressa.server`).
2. V hlavičke musí byť: `Push (APNs): zapnutý, production, topic sk.sikuta.Congressa`.
   To isté vidno v prehliadači na `http://127.0.0.1:8000/api/health` ako `"pushEnabled": true`.
3. Na iPhone: v aplikácii **Nastavenia → Zdroj programu** zadajte adresu servera a dajte *Obnoviť program*.
   Povoľte hlásenia. Zariadenie sa serveru ohlási — v `/admin` ho uvidíte v tabuľke **Zariadenia**
   so stĺpcom **Push = áno**.
4. Test: v Mac aplikácii **Server a push → Poslať oznam s push notifikáciou…** (alebo v `/admin` sekcia
   *Poslať push oznam*). Na iPhone musí prísť notifikácia; v *Odoslané push notifikácie* uvidíte počty.

## 5. Čo server posiela sám

| Kedy | Komu |
|---|---|
| X minút pred bodom programu (X = nastavenie účastníka, predvolene 15) | body označené *Upozorniť všetkých* → všetkým; body v Mojom pláne, prihlásené a spoločenský program → podľa nastavení účastníka |
| Vlastné vystúpenie (prednáša, predsedá, sprevádza) | „You're on in 15 min“ / „Vystupujete o 15 min“ |
| Oznam naplánovaný na čas | všetkým so zapnutými oznamami |
| *Publikovať a upozorniť všetkých* | všetkým („Programme updated“) |
| Uvoľnené miesto z čakacej listiny | tomu, kto sa posunul |

## Riešenie problémov

| V logu / dashboarde | Čo s tým |
|---|---|
| `push vypnutý` | chýbajú `CONGRESSA_APNS_*` v `.env` alebo `.p8` nie je na uvedenej ceste (cesta je relatívna k priečinku servera) |
| `BadDeviceToken` | zlé `CONGRESSA_APNS_ENV` (production ↔ sandbox) alebo iné `CONGRESSA_APNS_TOPIC` než bundle ID appky |
| `InvalidProviderToken` | zlý Key ID alebo Team ID; skontrolujte aj dátum a čas na Mac Pro |
| `TooManyProviderTokenUpdates` | server posiela príliš veľa tokenov — reštartujte ho, kľúč sa cachuje na 50 minút |
| notifikácia nepríde, ale `sent` je 1 | na iPhone: Nastavenia → Hlásenia → Congressa → povoliť; skontrolujte režim sústredenia |

> Kľúč `.p8` je tajomstvo ako heslo: neposielajte ho e-mailom ani do chatu, priečinok `apns/` je v `.gitignore`.
