#!/bin/bash
# Congressa – neinteraktívny spúšťač pre launchd (trvalý server na Macu).
#   - žiadne prompty (launchd nemá terminál), .env sa načíta zo súboru,
#   - pri každom štarte zapne Tailscale Funnel na VLASTNOM uzle Congressy
#     (po reštarte Macu tak nabehne verejná adresa sama, bez klikania),
#   - `caffeinate -s` drží Mac bdelý po celý čas behu servera (pri napájaní zo siete).
#
# POZOR – ak na Macu beží viac projektov naraz (napr. Congressa + Carpoolka), každý potrebuje
# vlastný uzol Tailscale, lebo Funnel viaže adresu na názov uzla. Vtedy sa do .env doplní
# CONGRESSA_TS_SOCKET a všetky volania tailscale idú cez --socket, inak by sa Funnel nastavil
# tomu druhému projektu. Prázdna hodnota = jeden projekt, systémový tailscaled.
cd "$(dirname "$0")" || exit 1
if [ ! -f .env ]; then
    echo "CHYBA: .env neexistuje – rozklikni najprv START_CONGRESSA.command" >&2
    exit 1
fi
while IFS='=' read -r key value; do
    case "$key" in ''|\#*) continue ;; esac
    if [ -z "${!key:-}" ]; then export "$key=$value"; fi
done < .env
export PORT="${PORT:-8001}"

# Verejný https port Funnelu: 443 (adresa bez portu) | 8443 | 10000.
PUBLIC_HTTPS_PORT="${CONGRESSA_PUBLIC_HTTPS_PORT:-443}"
# Vlastný uzol Tailscale (viac projektov na jednom Macu). Prázdne = systémový tailscaled.
TS_SOCKET="${CONGRESSA_TS_SOCKET:-}"

# launchd dáva minimálny PATH, preto hľadáme tailscale aj na známych cestách.
TS="$(command -v tailscale || true)"
for CAND in /usr/local/bin/tailscale /opt/homebrew/bin/tailscale "/Applications/Tailscale.app/Contents/MacOS/Tailscale"; do
    [ -n "$TS" ] && break
    [ -x "$CAND" ] && TS="$CAND"
done

# Funnel nastavíme na pozadí: vlastný uzol sa po štarte Macu prihlasuje niekoľko sekúnd,
# preto naň chvíľu počkáme. Server medzitým normálne beží (lokálne aj cez Wi-Fi).
if [ -n "$TS" ]; then
    (
        if [ -n "$TS_SOCKET" ]; then
            for _ in $(seq 1 30); do
                [ -S "$TS_SOCKET" ] && "$TS" --socket="$TS_SOCKET" status >/dev/null 2>&1 && break
                sleep 2
            done
            "$TS" --socket="$TS_SOCKET" funnel --bg --https="$PUBLIC_HTTPS_PORT" "$PORT"
        else
            "$TS" funnel --bg --https="$PUBLIC_HTTPS_PORT" "$PORT"
        fi
    ) >> funnel.log 2>&1 &
fi

# Rotácia logov – bez nej server.log rastie donekonečna (staré pády pri konflikte portov).
for LOG in server.log funnel.log; do
    [ -f "$LOG" ] || continue
    SIZE=$(wc -c < "$LOG" | tr -d ' ')
    if [ "${SIZE:-0}" -gt 2000000 ]; then
        mv -f "$LOG" "$LOG.1"
        : > "$LOG"
    fi
done

exec caffeinate -s python3 congressa_server.py
